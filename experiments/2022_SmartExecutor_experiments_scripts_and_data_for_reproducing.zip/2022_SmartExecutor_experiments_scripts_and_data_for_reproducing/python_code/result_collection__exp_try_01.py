"""
extract data from batches of raw output

combine extract data of all batches



"""

import sys
import os
import csv
import pandas as pd
sys.path.append('C:\\Users\\18178\\_2022_exp\\python_code\\') # where the wei_utils.py resides
import wei_utils as wu
import numpy as np     

_dir='C:\\Users\\18178\\_2022_exp\\exp_try_01\Results\\' 


 




#============================================================================================================
# for collecting the actual time used 
#============================================================================================================

# # results_smartExecutor_prefix="results_smartExecutor_"     

# # path_suffix=['SE07_d1_5_3_1_1_7200_','SE07_d2_5_3_1_1_7200_','SE07_d3_5_3_1_1_7200_']     
   
# # files=['SE07_d1_5_3_1_1_7200_*.csv','SE07_d2_5_3_1_1_7200_*.csv','SE07_d3_5_3_1_1_7200_*.csv']  
# # merged_files=['SE07_d1_5_3_1_1_7200.csv','SE07_d2_5_3_1_1_7200.csv','SE07_d3_5_3_1_1_7200.csv']  

# # merged_smartExecutor_prefix='merged_smartExecutor_' 

# results_smartExecutor_prefix="results_smartExecutor_"     

# path_suffix=['SE06_d1_5_3_1_1_7200_','SE06_d2_5_3_1_1_7200_','SE06_d3_5_3_1_1_7200_']     
   
# files=['SE06_d1_5_3_1_1_7200_*.csv','SE06_d2_5_3_1_1_7200_*.csv','SE06_d3_5_3_1_1_7200_*.csv']  
# merged_files=['SE06_d1_5_3_1_1_7200.csv','SE06_d2_5_3_1_1_7200.csv','SE06_d3_5_3_1_1_7200.csv']  	  

# merged_smartExecutor_prefix='merged_smartExecutor_' 



#  # #====================================
# # extract results into csv files
# # #====================================    
# all_contracts_data_cut_down={}    
   
# for i in range(len(path_suffix)):
#     for index in range(1,11,1):
    
#         dir = _dir+ results_smartExecutor_prefix +  path_suffix[i] + str(index)+'/'
#         csv_file_name = _dir + results_smartExecutor_prefix +  path_suffix[i] +str(index)+"__csv.csv"
            
#         all_files = find_all_file(dir)
#         re = iterate_files(all_files)
#         contracts_data_cut_down=output_csv(re, csv_file_name)
#         if contracts_data_cut_down:
#             all_contracts_data_cut_down['part'+str(index)]=contracts_data_cut_down
# print(all_contracts_data_cut_down)




  

# # # #====================================
# # # combine all csv files of the same type into one csv files by executing windows commands
# # # #====================================

# # #====================================
# # # windows command to merge multiple csv files
# # example: copy results_mythril_*.csv merged_mythril.csv  
    
# for i in range(len(path_suffix)):
 
#     target_files=_dir+results_smartExecutor_prefix+files[i]
#     target_merged_file=_dir+merged_smartExecutor_prefix+merged_files[i]
        
#     os.system("copy {} {}".format(target_files,target_merged_file))







#================================================================================================================================================

  


#------------------------------------------------------------------------------   
# notes:
    # order: mythril tx2, mythril tx 3, our approach
    
    
 
    
    

results_mythril_prefix='results_mythril_d1_'  
results_smartExecutor_prefix="results_smartExecutor_SE07_d1_"  
path_suffix=['tx2_','tx3_','5_3_1_1_7200_']     
   
files=['tx2_*.csv','tx3_*.csv','5_3_1_1_7200_*.csv']  
merged_files=["__tx2.csv", "__tx3.csv","__cl5_3_1_1_7200.csv"]

output_csv_path="SE07_d1_final_combined_csv"
 
  
# result csv file names
merged_mythril_prefix=['merged_mythril_tx2','merged_mythril_tx3']
merged_smartExecutor_prefix='merged_smartExecutor_SE07_d1_' 

output_csv_path_vul="SE07_d1_final_combined_csv_vul"
    
output_csv_whole="SE07_d1_final_combined_whole_dataset"

select_cols=[1,2,3,4,10,12]

max_len_mythril=0
max_len_smartExecutor=0
select_columns_for_vul=[1,2,3,12] # initialize the columns that will be selected for vulnerability handle
                                # column with index 12 is used to filter data
                                # columns indexed by 1,2,3 are used to connect the data      



# compare our approach, mythril(tx3) to mythril(tx2)
def statitics_for_se06_se07(tool_name_1, tool_name_2, dataset_identifier,tool_identifier):     

    results_mythril_prefix="results_"+tool_name_1+"_"+dataset_identifier+"_"  
    results_smartExecutor_prefix="results_"+tool_name_2+"_"+tool_identifier+"_"+dataset_identifier+"_"  
    path_suffix=['tx2_','tx3_','5_3_1_1_7200_']     
       
    files=['tx2_*.csv','tx3_*.csv','5_3_1_1_7200_*.csv']  
    merged_files=["__tx2.csv", "__tx3.csv","__cl5_3_1_1_7200.csv"]
    
    output_csv_path=""+tool_identifier+"_"+dataset_identifier+"_final_combined_csv"
     
      
    # result csv file names
    merged_mythril_prefix=["merged_"+tool_name_1+"_tx2","merged_"+tool_name_1+"_tx3"]
    merged_smartExecutor_prefix="merged_"+tool_name_2+"_"+tool_identifier+"_"+dataset_identifier+"_"
    
    output_csv_path_vul=tool_identifier+"_"+dataset_identifier+"_final_combined_csv_vul"
        
    output_csv_whole=tool_identifier+"_"+dataset_identifier+"_final_combined_whole_dataset"
    
    select_cols=[1,2,3,4,10,12]
    
    max_len_mythril=0
    max_len_smartExecutor=0
    select_columns_for_vul=[1,2,3,12] # initialize the columns that will be selected for vulnerability handle
                                    # column with index 12 is used to filter data
                                    # columns indexed by 1,2,3 are used to connect the data  
   




    # #====================================
    # extract results into csv files
    # #====================================    
    all_contracts_data_cut_down={}    
       
    for i in range(len(path_suffix)):
        for index in range(1,11,1):
            if i<=1:
                dir = _dir+results_mythril_prefix + path_suffix[i] +str(index) + '/'
                csv_file_name = _dir + results_mythril_prefix +  path_suffix[i] +str(index)+"__csv.csv"           
            else:
                dir = _dir+ results_smartExecutor_prefix +  path_suffix[i] + str(index)+'/'
                csv_file_name = _dir + results_smartExecutor_prefix +  path_suffix[i] +str(index)+"__csv.csv"
                
            all_files = wu.find_all_file(dir,'txt')
            re = wu.iterate_files(all_files)
            contracts_data_cut_down=wu.output_csv(re, csv_file_name)
            if contracts_data_cut_down:
                all_contracts_data_cut_down['part'+str(index)]=contracts_data_cut_down
    print(all_contracts_data_cut_down)
    
    
    
        
    
    # #====================================
    # combine all csv files of the same type into one csv files by executing windows commands
    # #====================================
    
    # #====================================
    # # windows command to merge multiple csv files
    # example: copy results_mythril_*.csv merged_mythril.csv  
        
    for i in range(len(path_suffix)): 
        if i<=1:
            target_files=_dir+results_mythril_prefix+files[i]
            target_merged_file=_dir+merged_mythril_prefix[i]+merged_files[i]
           
        else:
            target_files=_dir+results_smartExecutor_prefix+files[i]
            target_merged_file=_dir+merged_smartExecutor_prefix+merged_files[i]
            
        os.system("copy {} {}".format(target_files,target_merged_file))
    
       
    
    
      
       
    
    
    
    #======================================================
    # merge important columns from each case
    #====================================================== 
      
    
    # define the names for columns
    column_names=["sol name",  "solc" , "contract","M2_time","M2_state","M2_cov"]
    cov_columns=["M2_cov"]
    time_columns=["M2_time"]
    state_columns=["M2_state"]
    cov_diff_columns=[]
    for i in range(len(path_suffix)):
        if i==1:            
            column_names.append("M3_time")
            column_names.append("M3_state")
            column_names.append("M3_cov")
            cov_columns.append("M3_cov")
            time_columns.append("M3_time")
            state_columns.append("M3_state")            
            cov_diff_columns.append("cov_diff_M2_M3")
        if i>1:
            suffix=path_suffix[i]
            column_names.append("SE"+suffix+"_time")
            column_names.append("SE"+suffix+"_state")
            column_names.append("SE"+suffix+"_cov")
            cov_columns.append("SE"+suffix+"_cov")
            time_columns.append("SE"+suffix+"_time")
            state_columns.append("SE"+suffix+"_state")            
            cov_diff_columns.append("cov_diff_M2_SE"+suffix)
       
    # merge results
    df_combined_results=pd.DataFrame()
    for index in range(len(merged_files)): 
        if index==0:
            path=_dir+merged_mythril_prefix[index]+merged_files[index]
            data_selected,max_len_mythril=wu.convert_csv_to_ndarray_0(path)
            
            # extract the useful information
            df_combined_results= pd.DataFrame(data_selected[:,select_cols], columns=["sol name", "solc" , "contract", "time", "state", "coverage"])
            
            df_combined_results.loc[(df_combined_results.time == '-'),'time']='0' 
            df_combined_results.loc[(df_combined_results.state == '-'),'state']='0' 
            df_combined_results["coverage"]=df_combined_results["coverage"].map(lambda x: x.rstrip('%'))            
            df_combined_results.loc[(df_combined_results.coverage == '-'),'coverage']='0'            
            df_combined_results["coverage"]=pd.to_numeric(df_combined_results["coverage"], downcast="float")
                       
        else:
            if index==1:
                path=_dir+merged_mythril_prefix[index]+merged_files[index]
                data_selected,max_len_mythril=wu.convert_csv_to_ndarray_0(path)
       
            else:
                path=_dir+merged_smartExecutor_prefix+merged_files[index] 
                data_selected,max_len_smartExecutor=wu.convert_csv_to_ndarray_0(path) 
            # extract the useful information 
            df_temp=pd.DataFrame(data_selected[:,select_cols], columns=["sol name", "solc" , "contract", "time", "state", "coverage"])
            df_temp["coverage"]=df_temp["coverage"].map(lambda x: x.rstrip('%'))
            df_temp.loc[(df_temp.time == '-'),'time']='0'
            df_temp.loc[(df_temp.state == '-'),'state']='0'
            df_temp.loc[(df_temp.coverage == '-'),'coverage']='0'
            df_temp["coverage"]=pd.to_numeric(df_temp["coverage"], downcast="float")
            
            df_combined_results = df_combined_results.merge(df_temp, on=["sol name",  "solc" , "contract"])
     
    df_combined_results.columns=column_names
    df_combined_results.to_csv(_dir+output_csv_path+".csv", sep=',')
    
    
    
    
    
    
    
    
    #======================================================
    # compute average time, the number of states, coverage and coverage difference
    #======================================================
    
    # no filteration (only 10 rows) 
    df_filtered = df_combined_results
    df_filtered.to_csv(_dir+output_csv_path+"_statistics_dataset.csv", sep=',')
    
    
    
    statistics=[]
    statistics_columns=["ave time","ave #_of_states","ave cov",">10","(5,10]","(0,5]","=0","[-5,0)","[-10,5)","<-10"]
    #wei: remember to change it according to how many batches or experiment results are considered
    indices=["Mythril(tx2)","Mythril(tx3)","our approach"]
    
    for i in range(0,len(path_suffix)):
        re=[]
        if i==4:            
            # get the coverage diff
            coverage_obj=np.sum(df_filtered[cov_columns[i:]].values,axis=1)/3
            time_obj=np.sum(df_filtered[time_columns[i:]].values.astype(np.int),axis=1)/3
            state_obj=np.sum(df_filtered[state_columns[i:]].values.astype(np.int),axis=1)/3
          
            re.append( np.average(time_obj))
            re.append(np.average(state_obj))
            re.append(np.average(coverage_obj)) 
        else:
                
            # get the coverage diff
            coverage_obj=df_filtered[cov_columns[i]].values
            time_obj=df_filtered[time_columns[i]].values
            state_obj=df_filtered[state_columns[i]].values
          
            re.append( np.average(time_obj.astype(np.int)))
            re.append(np.average(state_obj.astype(np.int)))
            re.append(np.average(coverage_obj))
                
        if i>0:  
            # get the coverage diff
            # cov_obj=df_filtered.apply(lambda x:f(x[cov_columns[0]],x[cov_columns[i]]),axis=1).values
            cov_obj=np.subtract(df_filtered[cov_columns[0]].values,coverage_obj)
            re.append(len(cov_obj[np.where(cov_obj>10)]))
            re.append(len(cov_obj[np.where((cov_obj>5) & (cov_obj<=10))]))
            re.append(len(cov_obj[np.where((cov_obj>0) & (cov_obj<=5))]))
            re.append(len(cov_obj[np.where(cov_obj==0)]))
            re.append(len(cov_obj[np.where((cov_obj>=-5) & (cov_obj<0))]))
            re.append(len(cov_obj[np.where((cov_obj>=-10) & (cov_obj<-5))]))
                       
            re.append(len(cov_obj[np.where(cov_obj<-10)]))        
        statistics.append(re)
    
       
    df_statistics=pd.DataFrame(statistics,columns=statistics_columns,index=indices)       
    df_statistics.to_csv(_dir+output_csv_path+"_statistics.csv", sep=',')
    
    
    
      
    
    
    
    
    #======================================================
    # compute vulnerability statistics
    #======================================================  
    
    # get the indices of the columns that are to be selected
    assert max_len_mythril>0
    assert max_len_smartExecutor>0
    max_len=max_len_smartExecutor
    if max_len_mythril>max_len_smartExecutor:
        max_len=max_len_mythril
    
    
    columns_names_vul=["sol name",  "solc" , "contract","coverage"] 
    start_index=1+3+4+3+6
    
    
    for i in range(start_index,max_len):
        select_columns_for_vul.append(i)
        columns_names_vul.append("vul_"+str(i-start_index))  
            
       
    # merge results
    df_combined_results_vul=pd.DataFrame()
    for index in range(len(merged_files)): 
        if index==0:
            path=_dir+merged_mythril_prefix[index]+merged_files[index]
            data_mythril,_=wu.convert_csv_to_ndarray(path,max_len)            
            # extract the useful information
            df_combined_results_vul= pd.DataFrame(data_mythril[:,select_columns_for_vul], columns=columns_names_vul)
            df_combined_results_vul["coverage"]=df_combined_results_vul["coverage"].map(lambda x: x.rstrip('%'))            
            df_combined_results_vul.loc[(df_combined_results_vul.coverage == '-'),'coverage']='0'            
            df_combined_results_vul["coverage"]=pd.to_numeric(df_combined_results_vul["coverage"], downcast="float")
                       
        else:
            if index==1:
                path=_dir+merged_mythril_prefix[index]+merged_files[index]
                data_smartExecutor,_=wu.convert_csv_to_ndarray(path,max_len)  
            else:
                path=_dir+merged_smartExecutor_prefix+merged_files[index] 
                data_smartExecutor,_=wu.convert_csv_to_ndarray(path,max_len) 
            # extract the useful information 
            df_temp=pd.DataFrame(data_smartExecutor[:,select_columns_for_vul], columns=columns_names_vul)
            df_temp["coverage"]=df_temp["coverage"].map(lambda x: x.rstrip('%'))
            df_temp.loc[(df_temp.coverage == '-'),'coverage']='0'
            df_temp["coverage"]=pd.to_numeric(df_temp["coverage"], downcast="float")
            
            df_combined_results_vul = df_combined_results_vul.merge(df_temp, on=["sol name",  "solc" , "contract"])
     
    
    # rename columns  
    rename_column_names=["sol name",  "solc" , "contract"]   
    for i in range(len(path_suffix)):
        if i>1:
            suffix=path_suffix[i]
            for item in columns_names_vul[3:]:
                rename_column_names.append("SE"+suffix+"_"+item)
        else:
            if i==1:
                for item in columns_names_vul[3:]:
                    rename_column_names.append('M3_'+item)
            else:
                for item in columns_names_vul[3:]:
                    rename_column_names.append('M2_'+item)
    # output results to a csv file
    df_combined_results_vul.columns=rename_column_names
    df_combined_results_vul.to_csv(_dir+output_csv_path_vul+".csv", sep=',')
    
    
    
     
    
    #********************************
    df_whole=df_combined_results.merge(df_combined_results_vul, on=["sol name",  "solc" , "contract"]) 
    df_whole.to_csv(_dir+output_csv_whole+".csv",index=False,line_terminator='\n')
       
    #********************************
    
    
    
    #======================================================
    # # for vulnerability analysis    
    # # remove contracts that have no data through the column coverage. if coverage==0, there is no data 
    # df_filtered_vul = df_combined_results_vul[df_combined_results_vul[columns_filter_vul[0]] >0]
    # df_filtered_vul = df_filtered_vul[df_filtered_vul[columns_filter_vul[1]] >0]
    df_filtered_vul = df_combined_results_vul
    
    df_filtered_vul.to_csv(_dir+output_csv_path_vul+"_statistics_dataset_whole.csv", sep=',')
    
    vul_interval=len(select_columns_for_vul)-3
    
    results=[]
    array_df_filtered_vul=df_filtered_vul.to_numpy()
    for i in range(array_df_filtered_vul.shape[0]):
        re=list(array_df_filtered_vul[i,0:4])       
        m_vul=array_df_filtered_vul[i,list(range(3+1,3+vul_interval))]         
      
        # save vuls in a dict
        m_dict={}
        for item in m_vul:
                if str(item).__contains__(':'):
                    m_dict[str(item).split(':')[0]]=str(item).split(':')[1]
        m_type_count=len(m_dict.keys()) # get the number of types
        m_vul_count=0 
        for value in m_dict.values(): # get the total number of vulnerabilities detected
            m_vul_count+=int(value)
        
        for idx in range(1, len(path_suffix)):
            se_vul=array_df_filtered_vul[i,list(range(3+idx*vul_interval+1,3+(idx+1)*vul_interval))] 
            re.append(array_df_filtered_vul[i,3+idx*vul_interval])
            
            comparison = m_vul == se_vul            
            if comparison.all(): re.append("equal")               
            else:  re.append("not equal")
                
            se_dict={}
            for item in se_vul:
                if str(item).__contains__(':'):
                    se_dict[str(item).split(':')[0]]=str(item).split(':')[1]
            se_type_count=len(se_dict.keys())
            se_vul_count=0 
            for value in se_dict.values(): # get the total number of vulnerabilities detected
                se_vul_count+=int(value)
           
            new=0
            loss=0
               
            
            for vul in se_dict.keys():         
                if vul not in m_dict.keys():
                    new+=1              
                    
            for vul in m_dict.keys(): 
                if vul not in se_dict.keys():
                    loss+=1
                    
            re+=[loss, new, m_type_count,se_type_count, m_type_count-se_type_count, m_vul_count, se_vul_count, m_vul_count-se_vul_count]
        
        results.append(re)
        
    df_statistics_vul=pd.DataFrame(results)
    # column_names_statistics_vul=["sol name",  "solc" , "contract","M_cov","SE_cov","is_equal","M_find_only","SE_find_only","M_#_type","SE_#_type","diff_#_type","M_#_vul","SE_#_vul","diff_#_vul"]
      
    # df_statistics_vul.columns=column_names_statistics_vul
    df_statistics_vul.to_csv(_dir+output_csv_path_vul+"_statistics_dataset_numbers"+".csv", sep=',')    
    
    
    
    
    # count the number of contracts for each interested metrics
    df_equal_or_not_vul=pd.DataFrame()
    column_interval=10 # based on the distance of the column with vaule of 'equal' or' not eqeual' to the next this type of column
    results_not_equal_vul=[["equal","not equal","M_find_only","SE_find_only","M_more_type","SE_more_type","M_more_vul","SE_more_vul"]]
    for i in range(1, len(path_suffix)):
        re_ary=[]
        re_equal_series=df_statistics_vul[ 5+(i-1)*column_interval].values 
        re_ary.append(len(re_equal_series[np.where(re_equal_series=="equal")]))
        re_ary.append(len(re_equal_series[np.where(re_equal_series=="not equal")]))       
        
        # get rows that have different vulnerabilities
        df_t=df_statistics_vul.loc[df_statistics_vul[  5+(i-1)*column_interval ]=='not equal',5+(i-1)*column_interval+1:5-2+i*column_interval]
        # count 
        df_t.columns=list(range(column_interval-2))
        for idx in range(column_interval-2): 
            if idx<2:
                obj_series=df_t.apply(lambda x: True if x[idx]>0 else False, axis=1)
                re_ary.append(len(obj_series[obj_series==True].index))
            if idx==4 or idx==7:
                obj_series_1=df_t.apply(lambda x: True if x[idx]>0 else False, axis=1)
                re_ary.append(len(obj_series_1[obj_series_1==True].index))
                obj_series_0=df_t.apply(lambda x: True if x[idx]<0 else False, axis=1)
                re_ary.append(len(obj_series_0[obj_series_0==True].index))           
    
            
        results_not_equal_vul.append(re_ary)
        
    df_equal_or_not_vul=pd.DataFrame(results_not_equal_vul)
    df_equal_or_not_vul.index=["","Mythril(tx3)","our approach"]
    
    df_equal_or_not_vul.to_csv(_dir+output_csv_path_vul+"_statistics"+".csv", sep=',')
   
 


# compare our approach to mythril(tx2) and mythril(tx3)
def statitics_for_se06_se07_1(tool_name_1, tool_name_2, dataset_identifier,tool_identifier):
    
    if tool_identifier=="SE07":
        results_mythril_prefix="results_"+tool_name_1+"_"+dataset_identifier+"_"  
    else:
        results_mythril_prefix="results_"+tool_name_1+"_"+dataset_identifier+"_se06"+"_"  
        
    results_smartExecutor_prefix="results_"+tool_name_2+"_"+tool_identifier+"_"+dataset_identifier+"_" 
    
    path_suffix=['tx2_','tx3_','5_3_1_1_7200_']     
       
    files=['tx2_*.csv','tx3_*.csv','5_3_1_1_7200_*.csv']  
    merged_files=["__tx2.csv", "__tx3.csv","__cl5_3_1_1_7200.csv"]
    
    output_csv_path=""+tool_identifier+"_"+dataset_identifier+"_final_combined_csv"
     
      
    # result csv file names
    merged_mythril_prefix=["merged_"+tool_name_1+"_tx2","merged_"+tool_name_1+"_tx3"]
    merged_smartExecutor_prefix="merged_"+tool_name_2+"_"+tool_identifier+"_"+dataset_identifier+"_"
    
    output_csv_path_vul=tool_identifier+"_"+dataset_identifier+"_final_combined_csv_vul"
        
    output_csv_whole=tool_identifier+"_"+dataset_identifier+"_final_combined_whole_dataset"
    
    select_cols=[1,2,3,4,10,12]
    
    max_len_mythril=0
    max_len_smartExecutor=0
    select_columns_for_vul=[1,2,3,12] # initialize the columns that will be selected for vulnerability handle
                                    # column with index 12 is used to filter data
                                    # columns indexed by 1,2,3 are used to connect the data  
   




    # #====================================
    # extract results into csv files
    # #====================================    
    all_contracts_data_cut_down={}    
       
    for i in range(len(path_suffix)):
        for index in range(1,11,1):
            if i<=1:
                dir = _dir+results_mythril_prefix + path_suffix[i] +str(index) + '/'
                csv_file_name = _dir + results_mythril_prefix +  path_suffix[i] +str(index)+"__csv.csv"           
            else:
                dir = _dir+ results_smartExecutor_prefix +  path_suffix[i] + str(index)+'/'
                csv_file_name = _dir + results_smartExecutor_prefix +  path_suffix[i] +str(index)+"__csv.csv"
                
            all_files = wu.find_all_file(dir,'txt')
            re = wu.iterate_files(all_files)
            contracts_data_cut_down=wu.output_csv(re, csv_file_name)
            if contracts_data_cut_down:
                all_contracts_data_cut_down['part'+str(index)]=contracts_data_cut_down
    print(all_contracts_data_cut_down)
    
    
    
        
    
    # #====================================
    # combine all csv files of the same type into one csv files by executing windows commands
    # #====================================
    
    # #====================================
    # # windows command to merge multiple csv files
    # example: copy results_mythril_*.csv merged_mythril.csv  
        
    for i in range(len(path_suffix)): 
        if i<=1:
            target_files=_dir+results_mythril_prefix+files[i]
            target_merged_file=_dir+merged_mythril_prefix[i]+merged_files[i]
           
        else:
            target_files=_dir+results_smartExecutor_prefix+files[i]
            target_merged_file=_dir+merged_smartExecutor_prefix+merged_files[i]
            
        os.system("copy {} {}".format(target_files,target_merged_file))
    
       
    
    
      
       
    
    
    
    #======================================================
    # merge important columns from each case
    #====================================================== 
      
    
    # define the names for columns
    column_names=["sol name",  "solc" , "contract","M2_time","M2_state","M2_cov"]
    cov_columns=["M2_cov"]
    time_columns=["M2_time"]
    state_columns=["M2_state"]
    cov_diff_columns=[]
    for i in range(len(path_suffix)):
        if i==1:            
            column_names.append("M3_time")
            column_names.append("M3_state")
            column_names.append("M3_cov")
            cov_columns.append("M3_cov")
            time_columns.append("M3_time")
            state_columns.append("M3_state")            
            cov_diff_columns.append("cov_diff_M2_M3")
        if i>1:
            suffix=path_suffix[i]
            column_names.append("SE"+suffix+"_time")
            column_names.append("SE"+suffix+"_state")
            column_names.append("SE"+suffix+"_cov")
            cov_columns.append("SE"+suffix+"_cov")
            time_columns.append("SE"+suffix+"_time")
            state_columns.append("SE"+suffix+"_state")            
            cov_diff_columns.append("cov_diff_M2_SE"+suffix)
       
    # merge results
    df_combined_results=pd.DataFrame()
    for index in range(len(merged_files)): 
        if index==0:
            path=_dir+merged_mythril_prefix[index]+merged_files[index]
            data_selected,max_len_mythril=wu.convert_csv_to_ndarray_0(path)
            
            # extract the useful information
            df_combined_results= pd.DataFrame(data_selected[:,select_cols], columns=["sol name", "solc" , "contract", "time", "state", "coverage"])
            
            df_combined_results.loc[(df_combined_results.time == '-'),'time']='0' 
            df_combined_results.loc[(df_combined_results.state == '-'),'state']='0' 
            df_combined_results["coverage"]=df_combined_results["coverage"].map(lambda x: x.rstrip('%'))            
            df_combined_results.loc[(df_combined_results.coverage == '-'),'coverage']='0'            
            df_combined_results["coverage"]=pd.to_numeric(df_combined_results["coverage"], downcast="float")
                       
        else:
            if index==1:
                path=_dir+merged_mythril_prefix[index]+merged_files[index]
                data_selected,max_len_mythril=wu.convert_csv_to_ndarray_0(path)
       
            else:
                path=_dir+merged_smartExecutor_prefix+merged_files[index] 
                data_selected,max_len_smartExecutor=wu.convert_csv_to_ndarray_0(path) 
            # extract the useful information 
            df_temp=pd.DataFrame(data_selected[:,select_cols], columns=["sol name", "solc" , "contract", "time", "state", "coverage"])
            df_temp["coverage"]=df_temp["coverage"].map(lambda x: x.rstrip('%'))
            df_temp.loc[(df_temp.time == '-'),'time']='0'
            df_temp.loc[(df_temp.state == '-'),'state']='0'
            df_temp.loc[(df_temp.coverage == '-'),'coverage']='0'
            df_temp["coverage"]=pd.to_numeric(df_temp["coverage"], downcast="float")
            
            df_combined_results = df_combined_results.merge(df_temp, on=["sol name",  "solc" , "contract"])
     
    df_combined_results.columns=column_names
    df_combined_results.to_csv(_dir+output_csv_path+".csv", sep=',')
    
    
    
    
    
    
    
    
    #======================================================
    # compute average time, the number of states, coverage and coverage difference
    #======================================================
    
    # no filteration (only 10 rows) 
    df_filtered = df_combined_results
    df_filtered.to_csv(_dir+output_csv_path+"_statistics_dataset.csv", sep=',')    
    
    
    statistics=[]
    statistics_columns=["ave time","ave #_of_states","ave cov",">10","(5,10]","(0,5]","=0","[-5,0)","[-10,5)","<-10"]
    #wei: remember to change it according to how many batches or experiment results are considered
    indices=["Mythril(tx2)","Mythril(tx3)","our approach vs Mythril(tx2) ","our approach vs Mythril(tx3) "]
    
    for i in range(0,len(path_suffix)):
        re=[]
        
        if i<2:
            # get the average
            coverage_obj=df_filtered[cov_columns[i]].values
            time_obj=df_filtered[time_columns[i]].values
            state_obj=df_filtered[state_columns[i]].values
          
            re.append( np.average(time_obj.astype(np.int)))
            re.append(np.average(state_obj.astype(np.int)))
            re.append(np.average(coverage_obj))
            statistics.append(re)
        if i>=2:
            # get the average
            coverage_obj=df_filtered[cov_columns[i]].values
            time_obj=df_filtered[time_columns[i]].values
            state_obj=df_filtered[state_columns[i]].values
     
            for idx in range(2): 
                re=[]                    
                re.append( np.average(time_obj.astype(np.int)))
                re.append(np.average(state_obj.astype(np.int)))
                re.append(np.average(coverage_obj))
                
                 # get the coverage diff between our approach and mythril(tx2)
                # cov_obj=df_filtered.apply(lambda x:f(x[cov_columns[0]],x[cov_columns[i]]),axis=1).values
                cov_obj=np.subtract(df_filtered[cov_columns[idx]].values,coverage_obj)
                re.append(len(cov_obj[np.where(cov_obj>10)]))
                re.append(len(cov_obj[np.where((cov_obj>5) & (cov_obj<=10))]))
                re.append(len(cov_obj[np.where((cov_obj>0) & (cov_obj<=5))]))
                re.append(len(cov_obj[np.where(cov_obj==0)]))
                re.append(len(cov_obj[np.where((cov_obj>=-5) & (cov_obj<0))]))
                re.append(len(cov_obj[np.where((cov_obj>=-10) & (cov_obj<-5))]))
                           
                re.append(len(cov_obj[np.where(cov_obj<-10)]))  
                statistics.append(re)
                
        
        # if i==4:            
        #     # get the coverage diff
        #     coverage_obj=np.sum(df_filtered[cov_columns[i:]].values,axis=1)/3
        #     time_obj=np.sum(df_filtered[time_columns[i:]].values.astype(np.int),axis=1)/3
        #     state_obj=np.sum(df_filtered[state_columns[i:]].values.astype(np.int),axis=1)/3
          
        #     re.append( np.average(time_obj))
        #     re.append(np.average(state_obj))
        #     re.append(np.average(coverage_obj))        
            
            
        
    
       
    df_statistics=pd.DataFrame(statistics,columns=statistics_columns,index=indices)       
    df_statistics.to_csv(_dir+output_csv_path+"_statistics.csv", sep=',')
    
    
    
      
    
    
    
    
    #======================================================
    # compute vulnerability statistics
    #======================================================  
    #----------------------------
    # merge the vulnerability info from all tools
    
    # get the indices of the columns that are to be selected
    assert max_len_mythril>0
    assert max_len_smartExecutor>0
    max_len=max_len_smartExecutor
    if max_len_mythril>max_len_smartExecutor:
        max_len=max_len_mythril
    
    
    columns_names_vul=["sol name",  "solc" , "contract","coverage"] 
    start_index=1+3+4+3+6
    
    
    for i in range(start_index,max_len):
        select_columns_for_vul.append(i)
        columns_names_vul.append("vul_"+str(i-start_index))  
            
       
    # merge results
    df_combined_results_vul=pd.DataFrame()
    for index in range(len(merged_files)): 
        if index==0:
            path=_dir+merged_mythril_prefix[index]+merged_files[index]
            data_mythril,_=wu.convert_csv_to_ndarray(path,max_len)            
            # extract the useful information
            df_combined_results_vul= pd.DataFrame(data_mythril[:,select_columns_for_vul], columns=columns_names_vul)
            df_combined_results_vul["coverage"]=df_combined_results_vul["coverage"].map(lambda x: x.rstrip('%'))            
            df_combined_results_vul.loc[(df_combined_results_vul.coverage == '-'),'coverage']='0'            
            df_combined_results_vul["coverage"]=pd.to_numeric(df_combined_results_vul["coverage"], downcast="float")
                       
        else:
            if index==1:
                path=_dir+merged_mythril_prefix[index]+merged_files[index]
                data_smartExecutor,_=wu.convert_csv_to_ndarray(path,max_len)  
            else:
                path=_dir+merged_smartExecutor_prefix+merged_files[index] 
                data_smartExecutor,_=wu.convert_csv_to_ndarray(path,max_len) 
            # extract the useful information 
            df_temp=pd.DataFrame(data_smartExecutor[:,select_columns_for_vul], columns=columns_names_vul)
            df_temp["coverage"]=df_temp["coverage"].map(lambda x: x.rstrip('%'))
            df_temp.loc[(df_temp.coverage == '-'),'coverage']='0'
            df_temp["coverage"]=pd.to_numeric(df_temp["coverage"], downcast="float")
            
            df_combined_results_vul = df_combined_results_vul.merge(df_temp, on=["sol name",  "solc" , "contract"])
     
    
    # rename columns  
    rename_column_names=["sol name",  "solc" , "contract"]   
    for i in range(len(path_suffix)):
        if i>1:
            suffix=path_suffix[i]
            for item in columns_names_vul[3:]:
                rename_column_names.append("SE"+suffix+"_"+item)
        else:
            if i==1:
                for item in columns_names_vul[3:]:
                    rename_column_names.append('M3_'+item)
            else:
                for item in columns_names_vul[3:]:
                    rename_column_names.append('M2_'+item)
    # output results to a csv file
    df_combined_results_vul.columns=rename_column_names
    df_combined_results_vul.to_csv(_dir+output_csv_path_vul+".csv", sep=',')
    
    
    
     
    
    #********************************
    df_whole=df_combined_results.merge(df_combined_results_vul, on=["sol name",  "solc" , "contract"]) 
    df_whole.to_csv(_dir+output_csv_whole+".csv",index=False,line_terminator='\n')
       
    #********************************
    
    
    
    #======================================================
    # # for vulnerability analysis    
    # # remove contracts that have no data through the column coverage. if coverage==0, there is no data 
    # df_filtered_vul = df_combined_results_vul[df_combined_results_vul[columns_filter_vul[0]] >0]
    # df_filtered_vul = df_filtered_vul[df_filtered_vul[columns_filter_vul[1]] >0]
    df_filtered_vul = df_combined_results_vul
    
    df_filtered_vul.to_csv(_dir+output_csv_path_vul+"_statistics_dataset_whole.csv", sep=',')
    
    vul_interval=len(select_columns_for_vul)-3
    
    results=[]
    array_df_filtered_vul=df_filtered_vul.to_numpy()
    
    for i in range(array_df_filtered_vul.shape[0]):
        for k in range(2):
            re=list(array_df_filtered_vul[i,0:4]) 
            
            # m_vul=array_df_filtered_vul[i,list(range(3+1,3+vul_interval))]         
            m_vul=array_df_filtered_vul[i,list(range(3+k*vul_interval+1,3+(k+1)*vul_interval))] 
            # save vuls in a dict
            m_dict={}
            for item in m_vul:
                    if str(item).__contains__(':'):
                        m_dict[str(item).split(':')[0]]=str(item).split(':')[1]
            m_type_count=len(m_dict.keys()) # get the number of types
            m_vul_count=0 
            for value in m_dict.values(): # get the total number of vulnerabilities detected
                m_vul_count+=int(value)
            # compare with our approach
            
            for idx in range(2, len(path_suffix)):
                se_vul=array_df_filtered_vul[i,list(range(3+idx*vul_interval+1,3+(idx+1)*vul_interval))] 
                re.append(array_df_filtered_vul[i,3+idx*vul_interval])
                
                comparison = m_vul == se_vul            
                if comparison.all(): re.append("equal")               
                else:  re.append("not equal")
                    
                se_dict={}
                for item in se_vul:
                    if str(item).__contains__(':'):
                        se_dict[str(item).split(':')[0]]=str(item).split(':')[1]
                se_type_count=len(se_dict.keys())
                se_vul_count=0 
                for value in se_dict.values(): # get the total number of vulnerabilities detected
                    se_vul_count+=int(value)
               
                new=0
                loss=0
                   
                
                for vul in se_dict.keys():         
                    if vul not in m_dict.keys():
                        new+=1              
                        
                for vul in m_dict.keys(): 
                    if vul not in se_dict.keys():
                        loss+=1
                        
                re+=[loss, new, m_type_count,se_type_count, m_type_count-se_type_count, m_vul_count, se_vul_count, m_vul_count-se_vul_count]    
        

        re=list(array_df_filtered_vul[i,0:4])       
        m_vul=array_df_filtered_vul[i,list(range(3+1,3+vul_interval))]         
      
        # save vuls in a dict
        m_dict={}
        for item in m_vul:
                if str(item).__contains__(':'):
                    m_dict[str(item).split(':')[0]]=str(item).split(':')[1]
        m_type_count=len(m_dict.keys()) # get the number of types
        m_vul_count=0 
        for value in m_dict.values(): # get the total number of vulnerabilities detected
            m_vul_count+=int(value)
        
        for idx in range(1, len(path_suffix)):
            se_vul=array_df_filtered_vul[i,list(range(3+idx*vul_interval+1,3+(idx+1)*vul_interval))] 
            re.append(array_df_filtered_vul[i,3+idx*vul_interval])
            
            comparison = m_vul == se_vul            
            if comparison.all(): re.append("equal")               
            else:  re.append("not equal")
                
            se_dict={}
            for item in se_vul:
                if str(item).__contains__(':'):
                    se_dict[str(item).split(':')[0]]=str(item).split(':')[1]
            se_type_count=len(se_dict.keys())
            se_vul_count=0 
            for value in se_dict.values(): # get the total number of vulnerabilities detected
                se_vul_count+=int(value)
           
            new=0
            loss=0
               
            
            for vul in se_dict.keys():         
                if vul not in m_dict.keys():
                    new+=1              
                    
            for vul in m_dict.keys(): 
                if vul not in se_dict.keys():
                    loss+=1
                    
            re+=[loss, new, m_type_count,se_type_count, m_type_count-se_type_count, m_vul_count, se_vul_count, m_vul_count-se_vul_count]
        
        results.append(re)
        
    df_statistics_vul=pd.DataFrame(results)
    # column_names_statistics_vul=["sol name",  "solc" , "contract","M_cov","SE_cov","is_equal","M_find_only","SE_find_only","M_#_type","SE_#_type","diff_#_type","M_#_vul","SE_#_vul","diff_#_vul"]
      
    # df_statistics_vul.columns=column_names_statistics_vul
    df_statistics_vul.to_csv(_dir+output_csv_path_vul+"_statistics_dataset_numbers"+".csv", sep=',')    
    
    
    
    
    # count the number of contracts for each interested metrics
    df_equal_or_not_vul=pd.DataFrame()
    column_interval=10 # based on the distance of the column with vaule of 'equal' or' not eqeual' to the next this type of column
    results_not_equal_vul=[["equal","not equal","M_find_only","SE_find_only","M_more_type","SE_more_type","M_more_vul","SE_more_vul"]]
    
    for i in range(1, len(path_suffix)):
        re_ary=[]
        re_equal_series=df_statistics_vul[ 5+(i-1)*column_interval].values 
        re_ary.append(len(re_equal_series[np.where(re_equal_series=="equal")]))
        re_ary.append(len(re_equal_series[np.where(re_equal_series=="not equal")]))       
        
        # get rows that have different vulnerabilities
        df_t=df_statistics_vul.loc[df_statistics_vul[  5+(i-1)*column_interval ]=='not equal',5+(i-1)*column_interval+1:5-2+i*column_interval]
        
        # count 
        df_t.columns=list(range(column_interval-2))
        for idx in range(column_interval-2): 
            if idx<2:
                obj_series=df_t.apply(lambda x: True if x[idx]>0 else False, axis=1)
                re_ary.append(len(obj_series[obj_series==True].index))
            if idx==4 or idx==7:
                obj_series_1=df_t.apply(lambda x: True if x[idx]>0 else False, axis=1)
                re_ary.append(len(obj_series_1[obj_series_1==True].index))
                obj_series_0=df_t.apply(lambda x: True if x[idx]<0 else False, axis=1)
                re_ary.append(len(obj_series_0[obj_series_0==True].index))           
    
            
        results_not_equal_vul.append(re_ary)
        
    df_equal_or_not_vul=pd.DataFrame(results_not_equal_vul)
    df_equal_or_not_vul.index=["","Mythril(tx2)-our approach","Mythril(tx3)-our approach"]
    
    df_equal_or_not_vul.to_csv(_dir+output_csv_path_vul+"_statistics"+".csv", sep=',')


       
def statitics_for_se05(): 
  
    results_smartExecutor_prefix="results_smartExecutor_"  
    path_suffix=['SE05_d1_5_3_1_1_7200_','SE05_d2_5_3_1_1_7200_','SE05_d3_5_3_1_1_7200_']     
       
    files=['*.csv','*.csv','*.csv']  
    merged_files=['SE05_d1_5_3_1_1_7200.csv','SE05_d2_5_3_1_1_7200.csv','SE05_d3_5_3_1_1_7200.csv']
    
    merged_smartExecutor_prefix='merged_smartExecutor_'

    
      # #====================================
    # extract results into csv files
    # #====================================    
    all_contracts_data_cut_down={}    
       
    for i in range(len(path_suffix)):
        for index in range(1,11,1):
        
            dir = _dir+ results_smartExecutor_prefix +  path_suffix[i] + str(index)+'/'
            csv_file_name = _dir + results_smartExecutor_prefix +  path_suffix[i] +str(index)+"__csv.csv"
                
            all_files = wu.find_all_file(dir,'txt')
            re = wu.iterate_files(all_files)
            contracts_data_cut_down=wu.output_csv(re, csv_file_name)
            if contracts_data_cut_down:
                all_contracts_data_cut_down['part'+str(index)]=contracts_data_cut_down
    print(all_contracts_data_cut_down)




  

    # # #====================================
    # # combine all csv files of the same type into one csv files by executing windows commands
    # # #====================================
    
    # #====================================
    # # windows command to merge multiple csv files
    # example: copy results_mythril_*.csv merged_mythril.csv  
        
    for i in range(len(path_suffix)):
     
        target_files=_dir+results_smartExecutor_prefix+path_suffix[i]+files[i]
        target_merged_file=_dir+merged_smartExecutor_prefix+merged_files[i]
            
        os.system("copy {} {}".format(target_files,target_merged_file))
    
        
   
      
    
statitics_for_se06_se07_1('mythril','smartExecutor','d1','SE06')
# statitics_for_se06_se07_1('mythril','smartExecutor','d2','SE06')
# statitics_for_se06_se07_1('mythril','smartExecutor','d3','SE06')   
    
# statitics_for_se05()   
   
    

