# -*- coding: utf-8 -*-
"""
Created on Sat Dec 25 13:40:22 2021

@author: 18178
"""


import sys
import os
import csv
import pandas as pd

import wei_utils as wu
import numpy as np     
import shutil
import math

_dir_base='C:\\Users\\18178\\_2022_exp\\__for_public\\'

sys.path.append(_dir_base+'python_code\\') # where the wei_utils.py resides

target='windows'

_dir=_dir_base+'__'+target+'_results\\'


#============================================================================================================
# find contracts that go through seqeuence generation phase
# divided them into 10 csv files (for Windows)
# divided them into 5 csv files (for Linux)
#============================================================================================================


results_smartExecutor_prefix="results_smartExecutor_" 
 
path_suffix=['5_3_1_1_600_']     
   
files=['5_3_1_1_600_*.csv']
  
merged_files=["cl5_3_1_1_600.csv"]
 
merged_smartExecutor_prefix='merged_smartExecutor_'
 
csv_prefix='sGuard_contracts_info_seq_'+target+"_"
csv_folder="csv_metadata_files_"+target+"_seq"


 
# #====================================
# extract results into csv files
# #====================================    
all_contracts_data_cut_down={}    
   
for i in range(len(path_suffix)):
    for index in range(0,20,1):

        dir = _dir+ results_smartExecutor_prefix +  path_suffix[i] + str(index)+'/'
        csv_file_name = _dir + results_smartExecutor_prefix +  path_suffix[i] +str(index)+"__csv.csv"
            
        all_files = wu.find_all_file(dir,'txt')
        re = wu.iterate_files(all_files)
        
        contracts_data_cut_down=wu.output_csv(re, csv_file_name)
        if contracts_data_cut_down:
            all_contracts_data_cut_down['part'+str(index)]=contracts_data_cut_down
print(all_contracts_data_cut_down)

 
    
        
    
# #====================================
# combine all csv files of the same type into one csv files by executing windows commands
# #====================================

# #====================================
# # windows command to merge multiple csv files
# example: copy results_mythril_*.csv merged_mythril.csv  
        
for i in range(len(path_suffix)): 
    target_files=_dir+results_smartExecutor_prefix+files[i]
    target_merged_file=_dir+merged_smartExecutor_prefix+merged_files[i]
        
    os.system("copy {} {}".format(target_files,target_merged_file))
    

# #====================================
# get the contracts that go through sequence generation
# #====================================
df_contracts_seq=pd.DataFrame()
for index in range(len(merged_files)):     
    # convert csv data into an array
    path=_dir+merged_smartExecutor_prefix+merged_files[index] 
    data_selected,max_len_smartExecutor=wu.convert_csv_to_ndarray_0(path) 
    # extract the useful information 
    df_temp=pd.DataFrame(data_selected[:,[0,1,2,3]], columns=["seq","sol name", "solc" , "contract"])
    
    df_contracts_seq =  df_temp[df_temp["seq"]=="True"]
    df_contracts_info=df_contracts_seq.iloc[:,[1,2,3]]



# check if a directory exists or not
csv_folder_dir=_dir_base+csv_folder  
if os.path.isdir(csv_folder_dir):
     shutil.rmtree(csv_folder_dir)
os.mkdir(csv_folder_dir)
    

   
    
# randomly select 100 contracts
indices=list(range(df_contracts_info.shape[0]))
np.random.seed(100)
selected_indices=np.random.choice(indices, size=100, replace=False)
print(selected_indices)
df_contracts_info_100=df_contracts_info.iloc[selected_indices,:]
# save 10copies
for i in range(10):
    df_contracts_info_100.to_csv(csv_folder_dir+"\\"+csv_prefix+"part_"+str(i)+".csv",index=False, header=False,sep=',', line_terminator='\n')
    







#========================
# the rest will add later


    



    
    
          
    
    
     