# -*- coding: utf-8 -*-
"""
Created on Tue Jan 18 00:26:48 2022

@author: 18178
"""
import matplotlib.pyplot as plt
import matplotlib as mpl
import pandas as pd


#https://github.com/jukuznets/jupyter-notebooks/blob/main/mpl-piechart.ipynb

_dir='C:\\Users\\18178\\_2022_exp\\python_code\\plot_pie\\'
            
df = pd.read_csv(_dir+'london_crime_by_lsoa.csv')
df.head()

            
# Select columns you need
df = df[['borough', 'major_category']]
# Group boroughs and crimes and count numbers
df_grouped = df.groupby(['borough', 'major_category']).size().reset_index()
# Create a pivot table
table = pd.pivot_table(df_grouped, index=['borough'], columns=['major_category'])
# Delete columns with Nan values and convert to integers
table = table.dropna(axis=1).astype(int)
table

        
row_num = [5] # No. of the row
font_color = 'black'
colors = ['#f7ecb0', '#ffb3e6', '#99ff99', '#66b3ff', '#c7b3fb','#ff6666', '#f9c3b7']
values = table.iloc[row_num].values.tolist()[0] # crime numbers
labels = [x[1] for x in table.columns] # crime names
title = table.iloc[row_num].index.values.tolist()[0] # borough
    

        
# Create subplots and a pie chart
fig, ax = plt.subplots(figsize=(10, 7), facecolor='white')
ax.pie(values, labels=labels, colors=colors, startangle=30, textprops={'color':font_color})
# Set title, its position, and font size
title = plt.title(title, fontsize=16, color=font_color)
title.set_position([.5, 1.02])
mpl.rcParams['font.size'] = 16.0
    
filename = 'pie-chart-single'
plt.savefig(_dir+filename+'.png', facecolor=('#e8f4f0'))
plt.show()




        
font_color = '#525252'
colors = ['#f7ecb0', '#ffb3e6', '#99ff99', '#66b3ff', '#c7b3fb','#ff6666', '#f9c3b7']
    
        
fig, axes = plt.subplots(3, 3, figsize=(10, 10), facecolor='#e8f4f0')
fig.delaxes(ax= axes[2,2])

# for i, (idx, row) in enumerate(table.head(8).iterrows()):
#     ax = axes[i // 3, i % 3]
#     row = row[row.gt(row.sum() * .01)]
#     print(ax)
#     print(row)

    
        
for i, (idx, row) in enumerate(table.head(8).iterrows()):
    ax = axes[i // 3, i % 3]
    row = row[row.gt(row.sum() * .01)]
    ax.pie(row, 
           labels=row.values, 
           startangle=30, 
           wedgeprops=dict(width=.5), # For donuts
           colors=colors, 
           textprops={'color':font_color})
    ax.set_title(idx, fontsize=16, color=font_color)
    
    legend = plt.legend([x[1] for x in row.index], 
                        bbox_to_anchor=(1.3, .87), # Legend position
                        loc='upper left',  
                        ncol=1, 
                        fancybox=True)
    for text in legend.get_texts():
        plt.setp(text, color=font_color) # Legend font color

fig.subplots_adjust(wspace=.2) # Space between charts

title = fig.suptitle('Categories of crime in London boroughs', y=.95, fontsize=20, color=font_color)
# To prevent the title from being cropped
plt.subplots_adjust(top=0.85, bottom=0.15)
    

my_data=[['Types of Vul','std=0',2],]
df_data=pd.DataFrame()


