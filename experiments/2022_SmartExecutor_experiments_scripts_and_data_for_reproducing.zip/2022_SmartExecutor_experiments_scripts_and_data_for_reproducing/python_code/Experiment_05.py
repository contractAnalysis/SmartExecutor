


import sys
import os
import csv
import pandas as pd
sys.path.append('C:\\Users\\18178\\_2022_exp\\python_code\\') # where the wei_utils.py resides
import wei_utils as wu
import numpy as np     
import shutil
import math

_dir_base='C:\\Users\\18178\\_2022_exp\\experiment_05\\'

target='windows'
_dir=_dir_base+'__'+target+'_results\\'






# result folder names
results_mythril_prefix='results_mythril_'  
results_smartExecutor_prefix="results_smartExecutor_" 
    

# # #====================================
# # extract results into csv files
# # #====================================
index_range_whole=[[0,1],[2,3],[4,5]]
path_suffix_whole=[['300_tx2_','5_3_1_1_300_'],['600_tx2_','5_3_1_1_600_'],['900_tx2_','5_3_1_1_900_']] 

all_contracts_data_cut_down={}
for path_suffix, index_range in zip( path_suffix_whole,index_range_whole):
    # extract data into csv filess
    for i in range(len(path_suffix)):
        if i==0:
            dir = _dir+results_mythril_prefix + path_suffix[i] +str(index_range[i]) + '/'
            csv_file_name = _dir + results_mythril_prefix +  path_suffix[i] +str(index_range[i]) +"__csv.csv"           
        else:
            dir = _dir+ results_smartExecutor_prefix +  path_suffix[i] +str(index_range[i]) +'/'
            csv_file_name = _dir + results_smartExecutor_prefix +  path_suffix[i] +str(index_range[i]) +"__csv.csv"
            
        all_files = wu.find_all_file(dir,'txt')
        re = wu.iterate_files(all_files)
        contracts_data_cut_down=wu.output_csv(re, csv_file_name)
        if contracts_data_cut_down:
            all_contracts_data_cut_down['part'+str(index_range[i])]=contracts_data_cut_down
    print(all_contracts_data_cut_down)
            



path_suffix=['1200_tx2_','5_3_1_1_1200_']  
index_range=[[6,7],[8,9]]

for i in range(len(path_suffix)):
    for idx in index_range[i]:
        if i==0:
            dir = _dir+results_mythril_prefix + path_suffix[i] +str(idx) + '/'
            csv_file_name = _dir + results_mythril_prefix +  path_suffix[i] +str(idx) +"__csv.csv"           
        else:
            dir = _dir+ results_smartExecutor_prefix +  path_suffix[i] +str(idx) +'/'
            csv_file_name = _dir + results_smartExecutor_prefix +  path_suffix[i] +str(idx) +"__csv.csv"
            
        all_files = wu.find_all_file(dir,'txt')
        re = wu.iterate_files(all_files)
        contracts_data_cut_down=wu.output_csv(re, csv_file_name)
        if contracts_data_cut_down:
            all_contracts_data_cut_down['part'+str(idx)]=contracts_data_cut_down
print(all_contracts_data_cut_down)
            
# # #====================================
# # combine all csv files of the same type into one csv files by executing windows commands
# # #====================================
# # windows command to merge multiple csv files
# example: copy results_mythril_*.csv merged_mythril.csv  
files=['1200_tx2_*.csv','5_3_1_1_1200_*.csv']
merged_files=["_1200_tx2.csv", "__cl5_3_1_1_1200.csv"] 
merged_mythril_prefix='merged_mythril' 
merged_smartExecutor_prefix='merged_smartExecutor'     
   
for i in range(len(path_suffix)): 
    if i==0:
        target_files=_dir+results_mythril_prefix+files[i]
        target_merged_file=_dir+merged_mythril_prefix+merged_files[i]
       
    else:
        target_files=_dir+results_smartExecutor_prefix+files[i]
        target_merged_file=_dir+merged_smartExecutor_prefix+merged_files[i]
        
    os.system("copy {} {}".format(target_files,target_merged_file))






my_statistics=[]
# # #====================================
# # read data from csv files
# # #====================================
index_range_whole=[[0,1],[2,3],[4,5]]
path_suffix_whole=[['300_tx2_','5_3_1_1_300_'],['600_tx2_','5_3_1_1_600_'],['900_tx2_','5_3_1_1_900_']] 
select_cols=[1,2,3,4,10,12]
timeout=[300,600,900]
output_csv_prefix='final_combine_dataset_'
column_names=['solidity','solc','contract','Mythril_time','Mythril_#_states','Mythril_coverage','SE_time','SE_#_states',"SE_coverage"]
all_contracts_data_cut_down={}
t_idx=0
for path_suffix, index_range in zip( path_suffix_whole,index_range_whole):
    df_data=pd.DataFrame()
    # extract data into csv filess
    for i in range(len(path_suffix)):
        if i==0:           
            path = _dir + results_mythril_prefix +  path_suffix[i] +str(index_range[i]) +"__csv.csv" 
            m_data,max_len_m=wu.convert_csv_to_ndarray_0(path)
            df_data=pd.DataFrame(m_data)
            df_data=df_data[select_cols]
        else:            
            path= _dir + results_smartExecutor_prefix +  path_suffix[i] +str(index_range[i]) +"__csv.csv"
            se_data,max_len_se=wu.convert_csv_to_ndarray_0(path)
            df_temp=pd.DataFrame(se_data)
            df_temp=df_temp[select_cols]
            df_data=df_data.merge(df_temp, on=[1,2,3])
            df_data.columns=column_names

            df_data.to_csv(_dir_base+output_csv_prefix+str(timeout[t_idx])+"_origin.csv")
            
            
            df_data.loc[(df_data.Mythril_time == '-'),'Mythril_time']='0'
            df_data["Mythril_time"]=df_data["Mythril_time"].map(lambda x: int(x))
            df_data.loc[(df_data.Mythril_coverage == '-'),'Mythril_coverage']='0'
            df_data["Mythril_coverage"]=df_data["Mythril_coverage"].map(lambda x: float(x.rstrip('%'))) 
            df_data=df_data[df_data['Mythril_coverage']>0]
            
            df_data.loc[(df_data.SE_time == '-'),'SE_time']='0'
            df_data["SE_time"]=df_data["SE_time"].map(lambda x: int(x))
            df_data.loc[(df_data.SE_coverage == '-'),'SE_coverage']='0'
            df_data["SE_coverage"]=df_data["SE_coverage"].map(lambda x: float(x.rstrip('%'))) 
            df_data=df_data[df_data['SE_coverage']>0]
            df_data.to_csv(_dir_base+output_csv_prefix+"1200"+"_filter.csv") 

    my_statistics.append([timeout[t_idx],df_data['Mythril_time'].mean(),df_data['Mythril_coverage'].mean(),df_data['SE_time'].mean(),df_data['SE_coverage'].mean()])        
    t_idx+=1
    



# handle the case with timeout 1200
for i in range(len(merged_files)):     
    if i==0:           
        path =_dir+merged_mythril_prefix+merged_files[i]
        m_data,max_len_m=wu.convert_csv_to_ndarray_0(path)
        df_data=pd.DataFrame(m_data)
        df_data=df_data[select_cols]
    else:            
        path=_dir+merged_smartExecutor_prefix+merged_files[i]
        se_data,max_len_se=wu.convert_csv_to_ndarray_0(path)
        df_temp=pd.DataFrame(se_data)
        df_temp=df_temp[select_cols]
        df_data=df_data.merge(df_temp, on=[1,2,3])
        df_data.columns=column_names
        df_data.to_csv(_dir_base+output_csv_prefix+"1200"+"_origin.csv")
    
        df_data.loc[(df_data.Mythril_time == '-'),'Mythril_time']='0'
        df_data["Mythril_time"]=df_data["Mythril_time"].map(lambda x: int(x))
        df_data.loc[(df_data.Mythril_coverage == '-'),'Mythril_coverage']='0'
        df_data["Mythril_coverage"]=df_data["Mythril_coverage"].map(lambda x: float(x.rstrip('%'))) 
        df_data=df_data[df_data['Mythril_coverage']>0]
        
        df_data.loc[(df_data.SE_time == '-'),'SE_time']='0'
        df_data["SE_time"]=df_data["SE_time"].map(lambda x: int(x))
        df_data.loc[(df_data.SE_coverage == '-'),'SE_coverage']='0'
        df_data["SE_coverage"]=df_data["SE_coverage"].map(lambda x: float(x.rstrip('%'))) 
        df_data=df_data[df_data['SE_coverage']>0]
        df_data.to_csv(_dir_base+output_csv_prefix+"1200"+"_filter.csv") 
        
        my_statistics.append([1200,df_data['Mythril_time'].mean(),df_data['Mythril_coverage'].mean(),df_data['SE_time'].mean(),df_data['SE_coverage'].mean()])        


df_my_statistics=pd.DataFrame(my_statistics)
df_my_statistics.columns=['timeout','mythril_ave_time','mythril_ave_coverage','SE_ave_time','SE_ave_coverage']
df_my_statistics.to_csv(_dir_base+output_csv_prefix+"_my_statistics.csv")

