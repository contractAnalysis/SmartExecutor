#!/bin/bash

index=$1
data_file=$2
cli_timeout=$3
create_timeout=$4
execution_timeout=$5

result_folder_prefix=$6
depth=$7



contract_folder='sGuard_contracts'
csv_file_folder='experiment_02/csv_metadata_files_windows'


rm -rf ${result_folder_prefix}_${index}
mkdir ${result_folder_prefix}_${index}

exec < /home/mythril/${csv_file_folder}/${data_file} || exit 1
 # read header # read (and ignore) the first line
while IFS="," read file_name solc_version contract_name 
do
	 echo ""
	 #contract_name=${contract_nam:0:-1}
	 echo "++++ ${file_name}  :  ${solc_version}  :  ${contract_name} ++++" |& tee -a ./${result_folder_prefix}_${index}/"${file_name}__${contract_name}.txt" 
	 solc-select use "$solc_version" 	 
	

	 start=$SECONDS
	 
	timeout ${cli_timeout} myth analyze $(echo ./${contract_folder}/$file_name:${contract_name})  -t ${depth} --create-timeout ${create_timeout} --execution-timeout ${execution_timeout} |& tee -a ./${result_folder_prefix}_${index}/"${file_name}__${contract_name}.txt"


	end=$SECONDS
	runtime=$((end-start))
	echo "time_used: "${runtime}" seconds"	|& tee -a ./${result_folder_prefix}_${index}/"${file_name}__${contract_name}.txt"
	
	# save the time for each contract
	echo "#@contract_info_time" |& tee -a ./${result_folder_prefix}_${index}/"${file_name}__${contract_name}.txt"
	echo ${file_name[$i]}:${solc_version}:${contract_name}:${runtime}:${cli_timeout}:${create_timeout}:${execution_timeout} |& tee -a ./${result_folder_prefix}_${index}/"${file_name}__${contract_name}.txt"

	# one example of directing terminal ouput to file
	# echo "Solc version:" $solc_version >> ./analysis_result/"${file_name}__${contract_name}.txt" 2>&1
done

