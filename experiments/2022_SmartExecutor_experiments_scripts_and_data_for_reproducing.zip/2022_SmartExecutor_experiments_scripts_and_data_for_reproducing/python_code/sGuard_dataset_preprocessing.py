# -*- coding: utf-8 -*-
"""
Created on Sat Dec  4 09:27:54 2021

@author: 18178
=================================
handle the dataset of smart contracts from paper sGuard
=================================
    1, get the solc version from each source file
    2,clean the given all.csv file by removing "contracts/" from the file names
    3, get contract info: solidity file name, solc version, contract
    4, divide evenly contract info into 20 csv files
    5, make each line end with \n insteand of \r\n

"""



import pandas as pd
import sys
import math
import numpy as np


import shutil
import os

_dir_base='C:\\Users\\18178\\_2022_exp\\'


sys.path.append(_dir_base+'python_code\\') # where the wei_utils.py resides
import wei_utils as wu

_dir=_dir_base+'sGuard_contracts\\'

given_csv='all_updated.csv'
output_csv_prefix='sGuard_contracts_info'

_dir_csv_folder=_dir_base+'\\experiment_01\\csv_metadata_files_windows\\'

_dir_csv_folder_random=_dir_base+'\\experiment_01\\csv_metadata_files_windows_random\\'
num_group=20


#=================================
# 1, get the solc version 
file_solc=[]
files=wu.find_all_file(_dir,'sol')
for file in files:
    with open(file,'r', encoding='utf8') as fp:
       line = fp.readline()       
       while line:
           if line.startswith("pragma") and "solidity" in line:
               file_name=file.split('\\')[-1]                
               solc_version=line.split()[-1].strip(";").strip()
               if len(solc_version)==0:
                   solc_version=line.split()[-2].strip(";").strip()
               
               solc_version=''.join(i for i in solc_version if i.isdigit() or i in '.') # obtain solc version
               file_solc.append([file_name,solc_version])
               break          
           line = fp.readline()
df_file_solc=pd.DataFrame(file_solc)
          


#=================================
# 2,clean the given all.csv file by removing "contracts/" from the file names
# remove rows contains nan value or contracts with name 'SafeMath'
df_csv=pd.read_csv(_dir+given_csv,header=None)
df_csv[1]=df_csv[1].map(lambda x: x.split("/")[-1]) # remove "contracts/"
# df_csv_filtered= df_csv[(df_csv[0]!="NaN") & (df_csv[0]!="SafeMath")]
#df_csv_filtered= df_csv[df_csv[0]!="SafeMath"]
df_csv_filtered= df_csv.dropna()



#=================================
# 3, get contract info: solidity file name, solc version, contract
df_file_solc.columns=['Solidity file','solc version']
df_csv_filtered.columns=['contract name','Solidity file']
df_contract_info=df_csv_filtered.merge(df_file_solc, on=["Solidity file"])
columns_titles = ['Solidity file','solc version','contract name']
df_contract_info=df_contract_info.reindex(columns=columns_titles)# swap columns by giving a list of columns 
df_contract_info.to_csv(_dir+output_csv_prefix+".csv",index=False, header=False,sep=',') # output to a csv file



# #=================================
# # 4, divide evenly contract info into 20 csv files
# # 5, make each line end with \n insteand of \r\n
# # divided into 20 groups and get the size for each group

# # check if a directory exists or not
 
# if os.path.isdir(_dir_csv_folder):
#      shutil.rmtree(_dir_csv_folder)
# os.mkdir(_dir_csv_folder)
    

# group_size=math.floor((df_contract_info.shape[0]/num_group))
# left=df_contract_info.shape[0]-num_group*group_size
# group_size_list=num_group*[group_size]
# for i in range(left):
#     group_size_list[i]+=1
# index=0
# index_start=0
# for group_size in group_size_list:
#     group=df_contract_info.iloc[index_start:index_start+group_size]
#     group.to_csv(_dir_csv_folder+output_csv_prefix+"_part_"+str(index)+".csv",index=False, header=False,sep=',', line_terminator='\n')
#     index+=1
#     index_start+=group_size







#=================================
# randomly selecdt 100 smart contracts
row_indices=list(range(df_contract_info.shape[0])) 
np.random.seed(100)
selected_indices=np.random.choice(row_indices, size=100, replace=False)               

print(selected_indices)

# check if a directory exists or not 
if os.path.isdir(_dir_csv_folder_random):
     shutil.rmtree(_dir_csv_folder_random)
os.mkdir(_dir_csv_folder_random)
    
df_contract_info_selected=df_contract_info.iloc[selected_indices]
for index in range(5): # get 5 csv files of the same contents
    df_contract_info_selected.to_csv(_dir_csv_folder_random+output_csv_prefix+"_random100_"+str(index)+".csv",index=False, header=False,sep=',', line_terminator='\n')       

# divide selected contracts into groups
num_group=2
group_size=math.floor((df_contract_info_selected.shape[0]/num_group))
left=df_contract_info_selected.shape[0]-num_group*group_size
group_size_list=num_group*[group_size]
for i in range(left):
    group_size_list[i]+=1
index=0
index_start=0
for group_size in group_size_list:
    group=df_contract_info_selected.iloc[index_start:index_start+group_size]
    group.to_csv(_dir_csv_folder_random+output_csv_prefix+"_random100_part_"+str(index)+".csv",index=False, header=False,sep=',', line_terminator='\n')
    index+=1
    index_start+=group_size






