


import sys
import os
import csv
import pandas as pd
sys.path.append('C:\\Users\\18178\\_2022_exp\\python_code\\') # where the wei_utils.py resides
import wei_utils as wu
import numpy as np     
import shutil
import math

_dir_base='C:\\Users\\18178\\_2022_exp\\experiment_01\\'

target='windows'
_dir=_dir_base+'__'+target+'_results\\'


#============================================================================================================
# get statistics from results
#============================================================================================================


results_smartExecutor_prefix="results_smartExecutor_"
results_mythril_prefix="results_mythril_" 
 
path_suffix=['600_tx2_','5_3_1_1_600_']     
   
files=['600_tx2_*.csv','5_3_1_1_600_*.csv']
  
merged_files=['_600_tx2.csv','_5_3_1_1_600.csv']
 
merged_smartExecutor_prefix='merged_smartExecutor_'
merged_mythril_prefix='merged_mythril_'

csv_prefix="final_results_"



 
# #====================================
# extract results into csv files
# #====================================    
all_contracts_data_cut_down={}    
   
for i in range(len(path_suffix)): 
    for index in range(0,20,1):
        csv_file_name=''
        dir=''
        if i==0:
            dir = _dir+ results_mythril_prefix +  path_suffix[i] + str(index)+'/'    
            csv_file_name = _dir + results_mythril_prefix +  path_suffix[i] +str(index)+"__csv.csv"
        else:
            dir = _dir+ results_smartExecutor_prefix +  path_suffix[i] + str(index)+'/'
            csv_file_name = _dir + results_smartExecutor_prefix +  path_suffix[i] +str(index)+"__csv.csv"
        all_files = wu.find_all_file(dir,'txt')
        re = wu.iterate_files(all_files)
     
        contracts_data_cut_down=wu.output_csv(re, csv_file_name)
        if contracts_data_cut_down:
            all_contracts_data_cut_down[f'part_tool_{i}_{index}']=contracts_data_cut_down      
            
print(all_contracts_data_cut_down)

 
    
        
    
# #====================================
# combine all csv files of the same type into one csv files by executing windows commands
# #====================================

# #====================================
# # windows command to merge multiple csv files
# example: copy results_mythril_*.csv merged_mythril.csv  
        
for i in range(len(path_suffix)):
    target_files=''
    target_merged_file=''
    if i==0:
        target_files=_dir+results_mythril_prefix+files[i]
        target_merged_file=_dir+merged_mythril_prefix+merged_files[i]
    else:
        target_files=_dir+results_smartExecutor_prefix+files[i]
        target_merged_file=_dir+merged_smartExecutor_prefix+merged_files[i]  
    os.system("copy {} {}".format(target_files,target_merged_file))
    


# #====================================
# get the data from merged files
# #====================================

path=_dir+merged_mythril_prefix+merged_files[0] 
data_array,max_len_mythril=wu.convert_csv_to_ndarray_0(path)
df_mythril=pd.DataFrame(data_array)

# merge the results of SmartExecutor (combine the results of contracts that are executed 3 times) 
path=_dir+merged_smartExecutor_prefix+merged_files[1] 
data_array,max_len_smartExecutor=wu.convert_csv_to_ndarray_0(path)
df_SE=pd.DataFrame(data_array)


# get the  time, the number of states, and code coverage 
df_mythril_no_cov = df_mythril[df_mythril[12]=='-']
df_mythril_2_more_cov = df_mythril[df_mythril[13]!='-']
df_mythril_2_cov = df_mythril[(df_mythril[12]!='-')&(df_mythril[13]=='-')]
selected_columns_mythril=[1,2,3,4,10,12]
df_mythril_2_cov_select=df_mythril_2_cov.loc[:,selected_columns_mythril]
df_mythril_2_cov_select[12]=df_mythril_2_cov_select[12].map(lambda x:float(str(x).strip('%')))
df_mythril_2_cov_select[4]=df_mythril_2_cov_select[4].map(lambda x:int(x))
df_mythril_2_cov_select[10]=pd.to_numeric(df_mythril_2_cov_select[10],downcast='integer')
column_names_M=['solidity', 'solc', 'contract','M_time','M_num_states','M_coverage']
df_mythril_2_cov_select.columns=column_names_M
      
# get the  time, the number of states, and code coverage 
df_SE_no_cov = df_SE[df_SE[12]=='-']
df_SE_2_more_cov = df_SE[df_SE[13]!='-']
df_SE_2_cov = df_SE[(df_SE[12]!='-')&(df_SE[13]=='-')]
selected_columns_smartExecutor=[1,2,3,4,10,12]
df_SE_2_cov_select=df_SE_2_cov.loc[:,selected_columns_smartExecutor]
df_SE_2_cov_select[12]=df_SE_2_cov_select[12].map(lambda x:float(str(x).strip('%')))
df_SE_2_cov_select[4]=df_SE_2_cov_select[4].map(lambda x:int(x))
df_SE_2_cov_select[10]=pd.to_numeric(df_SE_2_cov_select[10],downcast='integer')
column_names_SE=['solidity', 'solc', 'contract','SE_time','SE_num_states','SE_coverage']
df_SE_2_cov_select.columns=column_names_SE

df_combined_results=df_SE_2_cov_select.merge(df_mythril_2_cov_select, on=['solidity', 'solc', 'contract'])
df_combined_results.to_csv(_dir+csv_prefix+"_time_state_coverage_dataset.csv", sep=',')



df_statistics=df_combined_results
statistics=[]
statistics.append([df_statistics['M_time'].mean(),df_statistics['M_num_states'].mean(),df_statistics['M_coverage'].mean()])

df_statistics["coverage_diff"]=df_combined_results['M_coverage']-df_combined_results["SE_coverage"]
re=[df_statistics['SE_time'].mean(),df_statistics['SE_num_states'].mean(),df_statistics['SE_coverage'].mean()]
cov_diff_obj=df_statistics['coverage_diff'].values

re.append(len(cov_diff_obj[np.where(cov_diff_obj>10)]))
re.append(len(cov_diff_obj[np.where((cov_diff_obj>5) & (cov_diff_obj<=10))]))
re.append(len(cov_diff_obj[np.where((cov_diff_obj>0) & (cov_diff_obj<=5))]))
re.append(len(cov_diff_obj[np.where(cov_diff_obj==0)]))
re.append(len(cov_diff_obj[np.where((cov_diff_obj>=-5) & (cov_diff_obj<0))]))
re.append(len(cov_diff_obj[np.where((cov_diff_obj>=-10) & (cov_diff_obj<-5))]))                   
re.append(len(cov_diff_obj[np.where(cov_diff_obj<-10)]))

statistics.append(re)

df_statistics["time_diff"]=df_combined_results['M_time']-df_combined_results["SE_time"]
df_statistics_0=df_statistics[(df_statistics['time_diff']>=0) & (df_statistics['coverage_diff']<=0)]
statistics.append(["target contracts",df_statistics_0.shape[0]])
statistics.append(['total contracts',df_statistics.shape[0]])
statistics.append(["percentage",df_statistics_0.shape[0]/df_statistics.shape[0]])

statistics_columns=["ave time","ave num_states","ave coverage",">10","(5,10]","(0,5]","=0","[-5,0)","[-10,5)","<-10"]
indices=["Mythril","my approach","","",""]
df_statistics=pd.DataFrame(statistics,columns=statistics_columns,index=indices)       
df_statistics.to_csv(_dir+csv_prefix+"_statistics.csv", sep=',')








#======================================================
# compute vulnerability statistics
#======================================================  

# merge the vulerability data

max_len=max_len_mythril if max_len_mythril>=max_len_smartExecutor else max_len_smartExecutor
columns_names_vul=["sol name",  "solc" , "contract","time","num_states","coverage","coverage_1"] 
select_columns_for_vul=[1,2,3,4,10,12,13]

start_index=1+3+4+3+6
for i in range(start_index,max_len):
    select_columns_for_vul.append(i)
    columns_names_vul.append("vul_"+str(i-start_index))  
        

index=0
path=_dir+merged_mythril_prefix+merged_files[index]
data_mythril,_=wu.convert_csv_to_ndarray(path,max_len)            
# extract the useful information
df_vul_mythril= pd.DataFrame(data_mythril[:,select_columns_for_vul], columns=columns_names_vul)
df_vul_mythril_2_cov = df_vul_mythril[(df_vul_mythril["coverage"]!='-')&(df_vul_mythril["coverage_1"]=='-')]

df_vul_mythril_2_cov["coverage"]=df_vul_mythril_2_cov["coverage"].map(lambda x: float(x.rstrip('%')))            
# df_vul_mythril_2_cov.loc[(df_vul_mythril_2_cov.coverage == '-'),'coverage']='0'            
# df_vul_mythril_2_cov["coverage"]=pd.to_numeric(df_vul_mythril_2_cov["coverage"], downcast="float")

df_vul_mythril_2_cov["num_states"]=df_vul_mythril_2_cov["num_states"].map(lambda x:int(x))
df_vul_mythril_2_cov["time"]=df_vul_mythril_2_cov["time"].map(lambda x:int(x))

df_vul_mythril_2_cov=df_vul_mythril_2_cov.drop(columns=["coverage_1"])  # column coverage_1 is used to remove contracts that have more than 2 coverage items. so it is dropped

         
index=1 
path=_dir+merged_smartExecutor_prefix+merged_files[index] 
data_smartExecutor,_=wu.convert_csv_to_ndarray(path,max_len) 
# extract the useful information 
df_vul_SE=pd.DataFrame(data_smartExecutor[:,select_columns_for_vul], columns=columns_names_vul)
df_vul_SE_2_cov = df_vul_SE[(df_vul_SE["coverage"]!='-')&(df_vul_SE["coverage_1"]=='-')]


df_vul_SE_2_cov["coverage"]=df_vul_SE_2_cov["coverage"].map(lambda x: float(x.rstrip('%')))
# df_vul_SE_2_cov.loc[(df_vul_SE_2_cov.coverage == '-'),'coverage']='0'
# df_vul_SE_2_cov["coverage"]=pd.to_numeric(df_vul_SE_2_cov["coverage"], downcast="float")

df_vul_SE_2_cov["num_states"]=df_vul_SE_2_cov["num_states"].map(lambda x:int(x))
df_vul_SE_2_cov["time"]=df_vul_SE_2_cov["time"].map(lambda x:int(x))

df_vul_SE_2_cov=df_vul_SE_2_cov.drop(columns=["coverage_1"])


df_vul_combined_results = df_vul_mythril_2_cov.merge(df_vul_SE_2_cov, on=["sol name",  "solc" , "contract"])

# rename columns  
rename_column_names=["sol name",  "solc" , "contract"]   
for i in range(2):
    if i>0: 
        rename_column_names.append('SE_time')
        rename_column_names.append('SE_num_states')
        rename_column_names.append('SE_coverage')
        for item in columns_names_vul[7:]:
            rename_column_names.append("SE_"+item)
    else:
        rename_column_names.append('M_time')
        rename_column_names.append('M_num_states')
        rename_column_names.append('M_coverage')
        for item in columns_names_vul[7:]:
            rename_column_names.append('M_'+item)
# output results to a csv file
df_vul_combined_results.columns=rename_column_names
df_vul_combined_results.to_csv(_dir+csv_prefix+"_vul_dataset.csv", sep=',')



#======================================================
# compapre the vulnerabilities 

vul_interval=max_len-start_index+1+2
results=[]
count_x=0

array_df_filtered_vul=df_vul_combined_results.to_numpy()

for i in range(array_df_filtered_vul.shape[0]):
    re=list(array_df_filtered_vul[i,0:6])       
    m_vul=array_df_filtered_vul[i,list(range(6,5+vul_interval-2))]         
  
    m_time= re[3]
    # save vuls in a dict
    m_dict={}
    for item in m_vul:
            if str(item).__contains__(':'):
                m_dict[str(item).split(':')[0]]=str(item).split(':')[1]
    m_type_count=len(m_dict.keys()) # get the number of types
    m_vul_count=0 
    for value in m_dict.values(): # get the total number of vulnerabilities detected
        m_vul_count+=int(value)
    
    for idx in range(1, 2):
        se_vul=array_df_filtered_vul[i,list(range(5+idx*vul_interval+1,5+(idx+1)*vul_interval-2))] 
        # get the time, the number of states and coverage 
        for item in array_df_filtered_vul[i,5+idx*vul_interval+1-3:5+idx*vul_interval+1]:
            re.append(item)        
        se_time=array_df_filtered_vul[i,13]
        
        comparison = m_vul == se_vul   
        flag_count_x=False         
        if comparison.all(): re.append("equal")               
        else:
            re.append("not equal")
            # check if SE has more vul than Mythril
            flag_count_x=True
                        
        se_dict={}
        for item in se_vul:
            if str(item).__contains__(':'):
                se_dict[str(item).split(':')[0]]=str(item).split(':')[1]
        se_type_count=len(se_dict.keys())
        se_vul_count=0 
        for value in se_dict.values(): # get the total number of vulnerabilities detected
            se_vul_count+=int(value)
       
        new=0
        loss=0 
        for vul in se_dict.keys():         
            if vul not in m_dict.keys():
                new+=1             
                
        for vul in m_dict.keys(): 
            if vul not in se_dict.keys():
                loss+=1
                
        if flag_count_x:            
            if loss==0 and m_vul_count<=se_vul_count:
                flag_se_more=True
                for key,value in se_dict.items():
                    if key in m_dict.keys():
                        m_value=m_dict[key]
                        if int(str(value).split(':')[-1])<int(str(m_value).split(':')[-1]):
                            flag_se_more=False
                            break
                if flag_se_more:
                    if str(se_time)=='-' or str(m_time)=='-':
                        pass
                    else:                       
                        if int(str(se_time))-int(str(m_time))<=0:
                            count_x+=1
                    
                
        re+=[loss, new, m_type_count,se_type_count, m_type_count-se_type_count, m_vul_count, se_vul_count, m_vul_count-se_vul_count]
    
    results.append(re)
    
df_statistics_vul=pd.DataFrame(results)
# column_names_statistics_vul=["sol name",  "solc" , "contract","M_cov","SE_cov","is_equal","M_find_only","SE_find_only","M_#_type","SE_#_type","diff_#_type","M_#_vul","SE_#_vul","diff_#_vul"]
  
# df_statistics_vul.columns=column_names_statistics_vul
df_statistics_vul.to_csv(_dir+csv_prefix+"_vul_statistics_dataset_numbers"+".csv", sep=',')    


 


# count the number of contracts for each interested metrics
column_interval=10 # based on the distance of the column with vaule of 'equal' or' not eqeual' to the next this type of column
results__vul=[["equal","not equal","M_find_only","SE_find_only","M_more_type","SE_more_type","M_more_vul","SE_more_vul"]]
plot_vul_data=[]
for i in range(1, 2):
    re_ary=[]
    re_equal_series=df_statistics_vul[ 9+(i-1)*column_interval].values 
    num_equal=len(re_equal_series[np.where(re_equal_series=="equal")])
    re_ary.append(num_equal)
    plot_vul_data.append(num_equal)
    num_not_equal=len(re_equal_series[np.where(re_equal_series=="not equal")])
    re_ary.append(num_not_equal)       
    plot_vul_data.append(num_not_equal)
    # get rows that have different vulnerabilities
    df_t=df_statistics_vul.loc[df_statistics_vul[  9+(i-1)*column_interval ]=='not equal',9+(i-1)*column_interval+1:9-2+i*column_interval]
    # count 
    df_t.columns=list(range(column_interval-2))
    for idx in range(column_interval-2): 
        if idx<2:
            obj_series=df_t.apply(lambda x: True if x[idx]>0 else False, axis=1)
            re_ary.append(len(obj_series[obj_series==True].index))
        if idx==4 or idx==7:
            obj_series_1=df_t.apply(lambda x: True if x[idx]>0 else False, axis=1)
            re_ary.append(len(obj_series_1[obj_series_1==True].index))
            plot_vul_data.append(len(obj_series_1[obj_series_1==True].index))
            
            obj_series_0=df_t.apply(lambda x: True if x[idx]<0 else False, axis=1)
            re_ary.append(len(obj_series_0[obj_series_0==True].index)) 
            plot_vul_data.append(len(obj_series_0[obj_series_0==True].index))
    results__vul.append(re_ary)
    
   
# get the average time, the number of states, and code coverage
results__vul.append(['average time','average # of states', "average coverage"])
results__vul.append([df_statistics_vul[3].mean(),df_statistics_vul[4].mean(),df_statistics_vul[5].mean()])
results__vul.append([df_statistics_vul[6].mean(),df_statistics_vul[7].mean(),df_statistics_vul[8].mean()])

# count
df_statistics_vul['time_diff']=df_statistics_vul[3]-df_statistics_vul[6]
df_statistics_vul['coverage_diff']=df_statistics_vul[5]-df_statistics_vul[8]
df_statistics_vul_0=df_statistics_vul[(df_statistics_vul['time_diff']>=0) & (df_statistics_vul['coverage_diff']<=0)]
results__vul.append([" contracts that SmartExecutor has higher coverage with the same or less time"])
results__vul.append(["target contracts",df_statistics_vul_0.shape[0]])
results__vul.append(['total contracts',df_statistics_vul.shape[0]])
results__vul.append(["percentage",df_statistics_vul_0.shape[0]/df_statistics_vul.shape[0]])


df_statistics_vul_1=df_statistics_vul[(df_statistics_vul['time_diff']>=0) & (df_statistics_vul[9]=='equal')]
count_y=df_statistics_vul_1.shape[0] # count from contracts that have the same vulnerabilities
results__vul.append([" contracts that SmartExecutor has more vulnerability with the same or less time"])
results__vul.append(["target contracts",count_x+count_y])
results__vul.append(['total contracts',df_statistics_vul.shape[0]])
results__vul.append(["percentage",(count_x+count_y)/df_statistics_vul.shape[0]])
  
indices=["","vul comparison","",'Mythril(2)','SmartExecutor',"","","","","","","","" ]
df_results__vul=pd.DataFrame(results__vul)
df_results__vul.index=indices
df_results__vul.to_csv(_dir_base+csv_prefix+"_vul_statistics"+".csv", sep=',')




#========================================================================================
# plot the number of states using scatter chart
#========================================================================================
import matplotlib.pyplot as plt
import pandas as pd


states=df_vul_combined_results[['M_num_states','SE_num_states']].astype(int)
states_order=states.sort_values('SE_num_states')


new_idx=list(range(len(states_order.index)))
states_order['new_idx']=new_idx

# gca stands for 'get current axis'
plt.figure(figsize=(7, 4))
ax = plt.gca()
states_order.plot(kind='scatter',x='new_idx',y='M_num_states',ax=ax, marker='x', label='Mythril (depth limit = 2)')
states_order.plot(kind='scatter',x='new_idx',y='SE_num_states',color='red', ax=ax, marker='.',label='SmartExecutor')
leg = ax.legend(loc="upper left", bbox_to_anchor=(0,0.9));
plt.xlabel('Indices of Contracts')
plt.ylabel('Number of Generated States')
plt.savefig(_dir_base+'comparison_number_of_states.pdf')
plt.show()


#========================================================================================
# plot vulnerability data with bar chart
#========================================================================================

total_num_contracts=df_statistics_vul.shape[0]
plot_data=[int(round((item/total_num_contracts)*100)) for item in plot_vul_data]
colors=['green','blue','lightblue','lightgreen','orange','pink']

# gca stands for 'get current axis'
plt.figure(figsize=(6, 3.5))
ax = plt.gca()

X = ["have the same Vul", "have different Vul",'Mythril has more types of Vul', "SmartExecutor has more types of Vul",'Mythril has larger number of Vul', "SmartExecutor has larger number of Vul"]
X_axis = np.arange(1,len(X)+1,1)

pps=ax.bar(X_axis - 0.2, plot_data, 0.5,color=colors)
for p in pps:
   height = p.get_height()
   ax.text(x=p.get_x() + p.get_width() / 2, y=height+.5,
      s="{}%".format(height),
      ha='center')

#The usual way to create a legend for objects which are not in the axes would be to create proxy artists 
handles = [plt.Rectangle((0,0),1,1, color=colors[idx]) for idx in range(len(X))]
plt.legend(handles, X)

# leg = ax.legend(loc="upper left", bbox_to_anchor=(0,0.9));
plt.xlabel('Categories')
plt.ylabel('Percentage of Contracts (%)')
plt.title('Vulnerability (Vul) Comparison between Mythril and SmartExecutor ')
plt.savefig(_dir_base+'vulnerability_comparison.pdf')
plt.show()

    


    
    
          
    
    
     