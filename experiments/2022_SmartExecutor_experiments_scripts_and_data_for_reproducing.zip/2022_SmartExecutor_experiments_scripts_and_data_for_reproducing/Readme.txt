
experiment_root_direcotry:   for example C:\User\xxx\Experiments\

experiment_01:  for RQ2
experiment_02:  for RQ1
experiment_04:  for RQ3

#=======================================
1 dataset preparation
2 pull docker images of tools and docker setting
3 prepare scripts for running experiments


#=======================================
1 dataset preparation
dataset 1: 
	available:  https://github.com/duytai/sGuard/issues/22
	downnload and put them in: experiment_root_direcotry\sGuard_contracts\



#=======================================
2 pull docker images of tools
Mythril:
	the version of Mythril we use: v0.22.19(released on April 5, 2021)
	available from https://github.com/ConsenSys/mythril/releases/tag/v0.22.19
	download the source and build the image from the source
	or use the image we use (only add some print statements to output info we want to collect):
	docker pull 23278942/smartexecutor:mythril_v0.22.19

SmartExecutor: 
	docker pull 23278942/smartexecutor:v07 
	docker pull 23278942/smartexecutor:v07x # created for experiments. This version enables to ouput code coverage for each function for both tools, executed function sequences executed only for SmartExecutor. 

docker setting (based on the resource of the machine you have)
	memory:16*20+16*2=352G
	cpu:2*20+2*2=44
	container: memory 16G, cpu 2
	here, I allow docker to use 352G memory and 44 cores so that all containers can have the assigned resources.


#=======================================
3 prepare scripts for running experiments

experiment_01:
	a) prepare the contract metadata (solidity file, solc version, contract name) and distribute them into 20 csv files
	Python script sGuard_dataset_preprocessing.py can achieve this. (to run this script, open it in Spyder, set the root directory experiment_root_direcotry, and click the "run" button.
 
	b) write *.sh and *.bat scripts that are executed in docker containers and windows respectively.
		here is a list of scripts:
			mythril_run.sh
			mythril_run_one_container_window.bat
			mythril_schedule_multiple_containers_windows.bat
			smartExecutor_run.sh
			smartExecutor_run_one_container_window.bat
			smartExecutor_schedule_multiple_containers_windows.bat
		
		put them in experiment_root_direcotry\experiment_01\__windows_scripts\
	
	c) run scripts
		open a command prompt
		go the the directory:experiment_root_direcotry\experiment_01\__windows_scripts\
		run command: 
			mythril_schedule_multiple_containers_windows.bat mythril_container 0 19 700 600 2			
			(
			mythril_container: used to as the prefix of the name of the created containers
			0 19: shows that there 20 containers with indices from 0 to 19
			700: command prompt timeout(s), which force the execution stop in case Mythril fails.
			600: the execution timeout set up for Mythril
			2: the depth limit (optional)
			)

			smartExecutor_schedule_multiple_containers_windows.bat smartExecutor_container 0 19 700 600 5 3 1 1	
			(
			5 3 1: values for control level, number of parent subsets, and the number of sequences generated for each parent sequence list. They are fixed in all experiments.
			the last 1: to indicate the times executed. 1 means the first time, while 2 means the second times.
			)
				
	d) result collection
		The result collection is done through experiment_01.py, which is in the folder:experiment_root_direcotry\python_code\. The script consists of a couple of code segements. Each code segment has done different jobs. To run it, you must open it in an IDE, which allows you run what you selected (Spyder for example)
		here are the steps:
			open experiment_01.py, 
			make sure the root directory is properly assigned
			select code segement
			click "Run" in the menu, select "Run selection or current line"

The rest of experiments follow the same style. 

		
Notes: I use the code of Mythril in the develop branch(April 8, 2021)
Mythril tag:v0.22.19, April 5, 2021
https://github.com/ConsenSys/mythril/releases/tag/v0.22.19


		