# -*- coding: utf-8 -*-
"""
Created on Sat Dec 25 13:40:53 2021

@author: 18178
"""

import sys
import os
import csv
import pandas as pd
sys.path.append('C:\\Users\\18178\\_2022_exp\\python_code\\') # where the wei_utils.py resides
import wei_utils as wu
import numpy as np     
import shutil
import math

_dir_base='C:\\Users\\18178\\_2022_exp\\experiment_02\\'




target='windows'
_dir=_dir_base+'__'+target+'_results\\'

results_mythril_prefix='results_mythril_7200_tx2_'
results_mythril_tx3_prefix='results_mythril_36000_tx3_'
results_SE_prefix='results_smartExecutor_5_3_1_1_7200_'
csv_folder="csv_metadata_files_target"



# get the data from the raw results
mythril_data_dict={}
mythril_tx3_data_dict={}
SE_data_dict={}

for i in range(0,20,1):
    folder_path=_dir+ results_mythril_prefix+str(i)
    all_files=wu.find_all_file(folder_path,'txt')
    for file in all_files:
        print(file)
        key=str(file).split("\\")[-1]
        results=wu.file_read_1(file)
        if key not in mythril_data_dict.keys():
            mythril_data_dict[key]=results
            
for i in range(0,20,1):
    folder_path=_dir+ results_mythril_tx3_prefix+str(i)
    all_files=wu.find_all_file(folder_path,'txt')
    for file in all_files:
        print(file)
        key=str(file).split("\\")[-1]
        results=wu.file_read_1(file)
        if key not in mythril_tx3_data_dict.keys():
            mythril_tx3_data_dict[key]=results

for i in range(0,20,1):
    folder_path=_dir+ results_SE_prefix + str(i)
    all_files=wu.find_all_file(folder_path,'txt')
    for file in all_files:
        print(file)
        key=str(file).split("\\")[-1]
        results=wu.file_read_1(file)
        if key not in SE_data_dict.keys():
            SE_data_dict[key]=results


target_contracts={} 
contract_info=[]           
# find contracts that have functions, on which SmartExecutor has higher code coverage than Mythril
for key,m_data in mythril_data_dict.items():
    target_ftn={}
    if key in SE_data_dict.keys():
        se_data=SE_data_dict[key]
        m_ftn_coverage=m_data[5]
        se_ftn_coverage=se_data[5]
        for ftn,m_cov in m_ftn_coverage.items():
            if ftn in se_ftn_coverage.keys():
                se_cov=se_ftn_coverage[ftn]
                diff=float(str(m_cov).strip('%'))-float(str(se_cov).strip('%'))
                if diff<=-5 and int(m_data[0][3])<7200 and int(se_data[0][3])<7200:
                    # get the executed function sequences for the target function
                    se_sequences_dict=se_data[7]
                    if ftn in se_sequences_dict.keys():                                         
                        target_ftn[ftn]=[m_data[0][3],se_data[0][3],m_cov,se_cov, diff,se_sequences_dict[ftn]]
    if len(target_ftn)>0:
        target_contracts[key]=target_ftn
        contract_info.append(m_data[0][0:3])
     
        
# get the number of contracts that either tools have timetout

contract_info_count_both=[]           
# find contracts that have functions, on which SmartExecutor has higher code coverage than Mythril
for key,m_data in mythril_data_dict.items():    
    if key in SE_data_dict.keys():
        se_data=SE_data_dict[key]
        if int(m_data[0][3])>7200 and int(se_data[0][3])>7200:
            my_d=list(m_data[0][0:3])+[m_data[0][3]]+[se_data[0][3]]
            contract_info_count_both.append(my_d)

contract_info_count_m=[]           
# find contracts that have functions, on which SmartExecutor has higher code coverage than Mythril
for key,m_data in mythril_data_dict.items():   
    if int(m_data[0][3])>7200 :
            my_d=list(m_data[0][0:3])+[m_data[0][3]]
            contract_info_count_m.append(my_d) 
            
contract_info_count_se=[]           
# find contracts that have functions, on which SmartExecutor has higher code coverage than Mythril
for key,se_data in SE_data_dict.items():   
    if int(se_data[0][3])>7200 :
            my_d=list(se_data[0][0:3])+[se_data[0][3]]
            contract_info_count_se.append(my_d) 
            
            
    
# #=================================
# # prepare the csv files for the following experiment   
# # check if a directory exists or not
# csv_folder_dir=_dir_base+csv_folder  
# if os.path.isdir(csv_folder_dir):
#      shutil.rmtree(csv_folder_dir)
# os.mkdir(csv_folder_dir) 


# # get target contrac info to the csv file
# out_csv_prefix='target_contract_info'
# df_target_contract=pd.DataFrame(contract_info)
# df_target_contract.to_csv(csv_folder_dir+"\\"+out_csv_prefix+"_whole.csv",index=False, header=False,sep=',', line_terminator='\n')    
# num_group=20
# #=================================
# #  divide evenly contract info into num_group csv files
# #  make each line end with \n insteand of \r\n
# group_size=math.floor((df_target_contract.shape[0]/num_group))
# left=df_target_contract.shape[0]-num_group*group_size
# group_size_list=num_group*[group_size]
# for i in range(left):
#     group_size_list[i]+=1
# index=0
# index_start=0
# for group_size in group_size_list:
#     group=df_target_contract.iloc[index_start:index_start+group_size]
#     group.to_csv(csv_folder_dir+"\\"+out_csv_prefix+"_part_"+str(index)+".csv",index=False, header=False,sep=',', line_terminator='\n')
 
#     index+=1
#     index_start+=group_size
    




#===================================================
# collect the results of target contracts
target_results=[] 
for key,value in target_contracts.items():
    
    m_data=mythril_data_dict[key]
    m_tx3_data=mythril_tx3_data_dict[key]
    se_data=SE_data_dict[key]
    
    result1=[]
    result1=m_data[0][0:3] # get solidity, solc, contract name
    
    result2=[]    
    result2.append(m_data[0][3]) # execution time
    if len(m_tx3_data[0])==0:
        result2.append(0)
    else:
        result2.append(m_tx3_data[0][3])    
    result2.append(se_data[0][3])
         
    # number of generated states
    result2.append(m_data[1][-1])
    if len(m_tx3_data[1])==0:
        result2.append(0)
    else:
        result2.append(m_tx3_data[1][-1])
    result2.append(se_data[1][-1])


   
    for ftn, ftn_data in value.items():        
        ftn_results=[]
        # add coverage
        cov_m_tx2=float(str(ftn_data[2]).strip('%'))
        ftn_results.append(cov_m_tx2) # coverage from Mythril (tx=2)
        cov_m_tx3=0
        tx3_cov_data=m_tx3_data[5] 
        if len(tx3_cov_data)>0:
            tx3_cov=tx3_cov_data[ftn]
            cov_m_tx3=float(str(tx3_cov).strip('%'))
            ftn_results.append(cov_m_tx3)
        else: ftn_results.append(0)
        cov_se=float(str(ftn_data[3]).strip('%'))
        ftn_results.append(cov_se) # coverage from SE   
        ftn_results.append(ftn_data[4]) # cov diff between mythril(tx2) and se
        ftn_results.append(cov_m_tx3-cov_se)# cov diff between mythril(tx3) and se
        # add valid sequences
        ftn_results.append(ftn_data[5]) 

        target_results.append(result1+[ftn]+result2+ftn_results)
    
df_target_results=pd.DataFrame(target_results)
column_names=['solidity file', 'solc','contract','function','time_tx2','time_tx3','time_se','#_states_tx2','#_states_tx3',"#_states_se",'cov_ftn_tx2','cov_ftn_tx3','cov_ftn_se','cov_diff_tx2_se','cov_diff_tx3_se','sequences_se']
df_target_results.columns=column_names
df_target_results.to_csv(_dir_base+"final_output.csv")



#===================================================
# only consider one function in each contract
# collect the results of target contracts
target_results=[] 
for key,value in target_contracts.items():
    collection=[]
    
    m_data=mythril_data_dict[key]
    m_tx3_data=mythril_tx3_data_dict[key]
    se_data=SE_data_dict[key]
    
    result1=[]
    result1=m_data[0][0:3] # get solidity, solc, contract name
    
    result2=[]    
    result2.append(m_data[0][3]) # execution time
    if len(m_tx3_data[0])==0:
        result2.append(0)
    else:
        result2.append(m_tx3_data[0][3])    
    result2.append(se_data[0][3])
         
    # number of generated states
    result2.append(m_data[1][-1])
    if len(m_tx3_data[1])==0:
        result2.append(0)
    else:
        result2.append(m_tx3_data[1][-1])
    result2.append(se_data[1][-1])
   
    for ftn, ftn_data in value.items():        
        ftn_results=[]
        # add coverage
        cov_m_tx2=float(str(ftn_data[2]).strip('%'))
        ftn_results.append(cov_m_tx2) # coverage from Mythril (tx=2)
        cov_m_tx3=0
        tx3_cov_data=m_tx3_data[5] 
        if len(tx3_cov_data)>0:
            tx3_cov=tx3_cov_data[ftn]
            cov_m_tx3=float(str(tx3_cov).strip('%'))
            ftn_results.append(cov_m_tx3)
        else: ftn_results.append(0)
        cov_se=float(str(ftn_data[3]).strip('%'))
        ftn_results.append(cov_se) # coverage from SE   
        ftn_results.append(ftn_data[4]) # cov diff between mythril(tx2) and se
        ftn_results.append(cov_m_tx3-cov_se)# cov diff between mythril(tx3) and se
        # add valid sequences
        ftn_results.append(ftn_data[5]) 
        collection.append(result1+[ftn]+result2+ftn_results)
        
    len_ele=len(collection)
    if len_ele>0:
        select_idx=np.random.choice(list(range(len_ele)),size=1)
    
        target_results.append(collection[select_idx[0]])
    
df_target_results_one=pd.DataFrame(target_results)
column_names=['solidity file', 'solc','contract','function','time_tx2','time_tx3','time_se','#_states_tx2','#_states_tx3',"#_states_se",'cov_ftn_tx2','cov_ftn_tx3','cov_ftn_se','cov_diff_tx2_se','cov_diff_tx3_se','sequences_se']
df_target_results_one.columns=column_names
df_target_results_one.to_csv(_dir_base+"final_output_v2.csv")




#=====================================================================
# plot function coverage in scatter chart

import matplotlib.pyplot as plt
import pandas as pd

# fiter some contracts that Mythril (tx=3, or tx=2) has 0 code coverage 
df_target_results_filter=df_target_results.loc[df_target_results["cov_ftn_tx3"]>0,:]
df_target_results_filter=df_target_results_filter.loc[df_target_results_filter["cov_ftn_tx2"]>0,:]

#-------------------------------------#
# plot function coverage
# get the data to plot
ftn_cov_np=df_target_results_filter[['cov_ftn_tx2','cov_ftn_tx3','cov_ftn_se']].astype(float)
ftn_cov_np_order=ftn_cov_np.sort_values('cov_ftn_se')

new_idx=list(range(len(ftn_cov_np_order.index)))
ftn_cov_np_order['new_idx']=new_idx

# two subplots
# fig, (ax1, ax2) = plt.subplots(1, 2,figsize=(8,4))
# ax1.scatter(x = ftn_cov_np_order['new_idx'], y = ftn_cov_np_order["cov_ftn_se"],marker = "o",color='blue',label='SmartExecutor')
# ax1.scatter(x = ftn_cov_np_order['new_idx'], y = ftn_cov_np_order["cov_ftn_tx2"],marker = "x",color='green',label='Mythril (depth limit = 2)')
# ax1.set_ylabel("Function Coverage")
# ax1.set_xlabel("Indices of Deeper Functions")
# ax1.legend(loc="lower right", bbox_to_anchor=(1,1))  

# ax2.scatter(x = ftn_cov_np_order['new_idx'], y = ftn_cov_np_order["cov_ftn_se"],marker = "o",color='blue',label='SmartExecutor')
# ax2.scatter(x = ftn_cov_np_order['new_idx'], y = ftn_cov_np_order["cov_ftn_tx3"],marker = "x",color='red',label='Mythril (depth limit = 3)')

# ax2.set_ylabel("Function Coverage")
# ax2.set_xlabel("Indices of Deeper Functions")
# ax2.legend(loc="lower right", bbox_to_anchor=(1,1))  
# fig.tight_layout()
# plt.savefig(_dir_base+"deeper_function_coverage.pdf")
# plt.show()

fig, (ax1, ax2) = plt.subplots(2,1,figsize=(6.5,4.5))
ax1.scatter(x = ftn_cov_np_order['new_idx'], y = ftn_cov_np_order["cov_ftn_se"],marker = "o",color='blue',label='SmartExecutor')
ax1.scatter(x = ftn_cov_np_order['new_idx'], y = ftn_cov_np_order["cov_ftn_tx2"],marker = "x",color='green',label='Mythril (depth limit = 2)')

ax1.set_ylim([10, 100])

ax1.set_ylabel("Function Coverage")
ax1.set_xlabel("Indices of Deep Functions")
ax1.legend(loc="lower right", bbox_to_anchor=(1,1))  

ax2.scatter(x = ftn_cov_np_order['new_idx'], y = ftn_cov_np_order["cov_ftn_se"],marker = "o",color='blue',label='SmartExecutor')
ax2.scatter(x = ftn_cov_np_order['new_idx'], y = ftn_cov_np_order["cov_ftn_tx3"],marker = "x",color='red',label='Mythril (depth limit = 3)')
ax2.set_ylim([10, 100])
ax2.set_ylabel("Function Coverage")
ax2.set_xlabel("Indices of Deep Functions")
ax2.legend(loc="lower right", bbox_to_anchor=(1,1))  
fig.tight_layout()
plt.savefig(_dir_base+"deep_function_coverage1.pdf")
plt.show()


# one plot
# gca stands for 'get current axis'
ax = plt.gca()
locs = ["upper left", "lower left", "center right"]
ftn_cov_np_order.plot(kind='scatter',x='new_idx',y="cov_ftn_se",color='blue',ax=ax,label='SmartExecutor')
# states_order.plot(kind='line',x='new_idx',y=6, color='red', ax=ax,label='SE-Guider')
ftn_cov_np_order.plot(kind='scatter',x='new_idx',y="cov_ftn_tx2", color='red', ax=ax,label='Mythril (depth limit = 2)')
ftn_cov_np_order.plot(kind='scatter',x='new_idx',y="cov_ftn_tx3", color='green', ax=ax,label='Mythril (depth limit = 3)')

# leg = ax.legend()
ax.legend(loc=locs[0], bbox_to_anchor=(1,1))
plt.xlabel('indices of contracts')
plt.ylabel('function coverage (%)')
# plt.savefig('outxx.pdf')
plt.show()




# #-------------------------------------
# # plot the coverage difference
# # get the data to plot
# ftn_cov_diff_np=df_target_results_filter[['cov_diff_tx2_se','cov_diff_tx3_se']].astype(float)
# ftn_cov_diff_np_order=ftn_cov_diff_np.sort_values('cov_diff_tx2_se',ascending=False)

# ftn_cov_diff_np_order=-ftn_cov_diff_np_order
# new_idx=list(range(len(ftn_cov_diff_np_order.index)))
# ftn_cov_diff_np_order['new_idx']=new_idx


# # two subplots
# fig, (ax1, ax2) = plt.subplots(1, 2,figsize=(5,6))
# ax2.scatter(x = ftn_cov_diff_np_order['new_idx'], y = ftn_cov_diff_np_order["cov_diff_tx2_se"],marker = "o",color='blue')
# ax2.scatter(x = ftn_cov_diff_np_order['new_idx'], y = ftn_cov_diff_np_order["cov_diff_tx3_se"],marker = 'x',color='red')
# ax2.set_ylabel("Function Coverage Difference")
# ax2.set_xlabel("Indices of Deeper Functions")
# ax2.legend(loc='best')  

# ax1.scatter(x = ftn_cov_diff_np_order['new_idx'], y = ftn_cov_diff_np_order["cov_diff_tx2_se"],marker = "o",color='blue')
# ax1.set_ylabel("Function Coverage Difference")
# ax1.set_xlabel("Indices of Deeper Functions")
# ax1.legend(loc='best')  

# fig.tight_layout()
# plt.savefig(_dir_base+"cov_ftn_difference.pdf")
# plt.show()


# #one plot
# # gca stands for 'get current axis'
# plt.figure(figsize=(6, 3.5))
# ax = plt.gca()

# locs = ["upper left", "lower left", "center right"]
# ftn_cov_diff_np_order.plot(kind='scatter',x='new_idx',y="cov_diff_tx2_se",color='blue',ax=ax, marker='s',label='SmartExecutor - Mythril (depth limit = 2)')
# # states_order.plot(kind='line',x='new_idx',y=6, color='red', ax=ax,label='SE-Guider')
# ftn_cov_diff_np_order.plot(kind='scatter',x='new_idx',y="cov_diff_tx3_se", color='red', ax=ax,marker='x',label='SmartExecutor - Mythril (depth limit = 3)')

# # leg = ax.legend()
# ax.legend(loc=locs[0], bbox_to_anchor=(0.05,1))
# # plt.figure(figsize=(13, 5))
# plt.xlabel('Indices of Contracts')
# plt.ylabel('Function Coverage Difference')
# plt.title("Function Coverage Difference between SmartExecutor and Mythril")
# plt.savefig(_dir_base+"cov_ftn_difference_v2.pdf")
# plt.show()



#------------------------------------
# plot execution time, and states with boxplots
time_np=df_target_results_filter[['time_tx2','time_tx3','time_se']].astype(int)
state_np=df_target_results_filter[['#_states_tx2','#_states_tx3','#_states_se']].astype(int)

labels = ['M2','M3','SE']
fig, axes = plt.subplots(1,2,figsize=(6,4)) # create figure and axes

# a way of making space (shrinking an axis):
box0 = axes[0].get_position()
axes[0].set_position([box0.x0, box0.y0-0.015, box0.width, box0.height+0.15])
box1 = axes[1].get_position()
axes[1].set_position([box1.x0, box1.y0-0.015, box1.width, box1.height+0.15])


b1=axes[0].boxplot(time_np, patch_artist=True, labels=labels,showfliers=False)
axes[0].set_ylabel("Execution Time (s)") 

# b2=axes[1].boxplot([state_np['#_states_tx2'],state_np['#_states_se'],state_np['#_states_tx3']])
b2=axes[1].boxplot(state_np,patch_artist=True,showfliers=False)
axes[1].set_xticklabels(labels ) 
axes[1].set_ylabel("Number of Generated States")


# fill with colors
colors = ['pink', 'lightblue', 'lightgreen']
for bplot in (b1,b2):
    for patch, color in zip(bplot['boxes'], colors):
        patch.set_facecolor(color)
        
# adding horizontal grid lines
for ax in axes:
    ax.yaxis.grid(True)
    # ax.set_xlabel('Execution Time')
    # ax.set_ylabel('Observed values') 

fig.legend((b1['boxes'][0],b1['boxes'][1],b1['boxes'][2]), ("M2: Mythril (depth limit = 2)","M3: Mythril (depth limit = 3)","SE: SmartExecutor"),\
           loc="lower left", bbox_to_anchor=(0,0.8))
fig.tight_layout()

plt.savefig(_dir_base+"time_states_boxplots.pdf")
plt.show()







#------------------------------------
# plot execution time with boxplots
time_np=df_target_results_filter[['time_tx2','time_se','time_tx3']].astype(int)


labels = ['M2','SE','M3']
fig, axes = plt.subplots(1,1,figsize=(6,4)) # create figure and axes

b1=axes.boxplot(time_np, patch_artist=True, labels=labels,showfliers=False)
axes.set_ylabel("Execution Time (s)") 
# axes.legend((b1['boxes'][0],b1['boxes'][1],b1['boxes'][2]), ("M2: Mythril (depth limit = 2)","SE: SmartExecutor","M3: Mythril (depth limit = 3)"),\
# loc="lower left", bbox_to_anchor=(0,0.8))


# fill with colors
colors = ['pink', '#038FC8', 'lightgreen']
for bplot in [b1]:
    for patch, color in zip(bplot['boxes'], colors):
        patch.set_facecolor(color)
        
# # adding horizontal grid lines
# for ax in axes:
#     ax.yaxis.grid(True)
#     # ax.set_xlabel('Execution Time')
#     # ax.set_ylabel('Observed values') 

fig.legend((b1['boxes'][0],b1['boxes'][1],b1['boxes'][2]), ("M2: Mythril (depth limit = 2)","SE: SmartExecutor","M3: Mythril (depth limit = 3)"),\
            loc="lower left", bbox_to_anchor=(0.2,0.7))
    
fig.tight_layout()

plt.savefig(_dir_base+"time_boxplots_RQ1.pdf")
plt.show()