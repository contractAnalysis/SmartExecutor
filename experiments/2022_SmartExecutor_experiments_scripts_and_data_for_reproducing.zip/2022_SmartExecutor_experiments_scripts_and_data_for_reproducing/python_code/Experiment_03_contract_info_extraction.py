# -*- coding: utf-8 -*-
"""
get: Solidty file name, solc version, contract name

@author: 18178
"""

import pandas as pd
import sys
import math
sys.path.append('C:\\Users\\18178\\_2022_exp\\python_code\\') # where the wei_utils.py resides
import wei_utils as wu
import os
import shutil


_dir_base="C:\\Users\\18178\\_2022_exp\\experiment_03\\"
target_vul=["access_control","arithmetic","bad_randomness","denial_of_service","front_running","other","reentrancy","short_addresses","time_manipulation","unchecked_low_level_calls"]
target_vul=["make_up"]


contract_info_csv_prefix=['SB_curated_'+item for item in target_vul]
csv_folders=[item+'_csv' for item in target_vul]




#============================================================================================================
# prepare for the dataset
#============================================================================================================

original_vul_data={}

#=================================
for i in range(len(target_vul)):
    dir_path=_dir_base+target_vul[i]    
   
    # 1, get the solc version 
    contract_info=[]
    contract_info_vul=[]
    files=wu.find_all_file(dir_path,'sol')
    for file in files:
        file_name=file.split('\\')[-1]   
        solc_version=""
        contract_name=[]
        vul_line='line'
        with open(file,'r', encoding='utf8') as fp:
            line = fp.readline()     
            while line:
                line=line.strip()
                if line.startswith("pragma"):                        
                    solc_version=line.split()[-1].strip(";").strip()
                    solc_version=''.join(i for i in solc_version if i.isdigit() or i in '.') # obtain solc version
                elif line.startswith("contract"):
                    temp=line.split()
                    if len(temp)>=2:
                        con_name=line.split()[1].strip('{')
                        contract_name.append(con_name)
                elif line.startswith("* @vulnerable_at_lines"):
                    vul_line+=line.split(":")[1]
                  
                line = fp.readline()
        for name in contract_name:
            contract_info.append([file_name,solc_version,name])            
        contract_info_vul.append([file_name,solc_version,contract_name,vul_line])       
    df_file_solc_contract=pd.DataFrame(contract_info)
    df_file_solc_contract_vul=pd.DataFrame(contract_info_vul)
    
    original_vul_data[target_vul[i]]=df_file_solc_contract_vul
    
    # check if a directory exists or not
    csv_folder_dir=_dir_base+csv_folders[i]   
    if os.path.isdir(csv_folder_dir):
          shutil.rmtree(csv_folder_dir)
    os.mkdir(csv_folder_dir)
    
    for idx in range(5):
        df_file_solc_contract.to_csv(csv_folder_dir+"\\"+contract_info_csv_prefix[i]+"_"+str(idx)+".csv",index=False,line_terminator='\n',header=None)
    df_file_solc_contract_vul.to_csv(csv_folder_dir+"\\"+contract_info_csv_prefix[i]+"_vul.csv",index=False,line_terminator='\n',header=None)
            
    
    
    
    
    
    
    
    
#============================================================================================================
# extract the results
#============================================================================================================    
import sys
import os
import csv
import pandas as pd
sys.path.append('C:\\Users\\18178\\_2022_exp\\python_code\\') # where the wei_utils.py resides
import wei_utils as wu
import numpy as np   

_dir="C:\\Users\\18178\\_2022_exp\\experiment_03\\__windows_results\\"  
target_vul=["access_control","arithmetic","bad_randomness","denial_of_service","front_running","other","reentrancy","short_addresses","time_manipulation","unchecked_low_level_calls"]



results_mythril_prefix='results_mythril_'  
results_smartExecutor_prefix="results_smartExecutor_SB_SE07_" 

path_suffix=["_900_tx2_0","_5_3_1_1_900_0" ] 



# #====================================
# extract results into csv files
# #====================================
all_contracts_data_cut_down={} 

for vul in target_vul:
    for i in range(len(path_suffix)):        
        result_folder_path=''
        csv_file_name=''
        if i==0:
            result_folder_path=_dir+results_mythril_prefix+vul+path_suffix[i]
            csv_file_name=_dir+results_mythril_prefix+vul+path_suffix[i]+"_csv.csv"
        else:
            result_folder_path=_dir+results_smartExecutor_prefix+vul+path_suffix[i]
            csv_file_name=_dir+results_smartExecutor_prefix+vul+path_suffix[i]+"_csv.csv" 
        
        all_files = wu.find_all_file(result_folder_path,'txt') 
        result_dict = {}
        for file in all_files:
            re=wu.file_read__vul_line(file)
            result_dict[file.split('/')[-1]]=re
        
        
        contracts_data_cut_down=wu.output_csv__vul_line(result_dict, csv_file_name)
        if contracts_data_cut_down:
            all_contracts_data_cut_down['part'+vul+str(i)]=contracts_data_cut_down 
        
print(all_contracts_data_cut_down)
   

        

# #====================================
# merge csv files to get execution time, the number of states, and code coverage
# #====================================
# define the names for columns for the merged dataframe
column_names=["sol name",  "solc" , "contract","M_time","M_state","M_cov"]
cov_columns=["M_cov"]
time_columns=["M_time"]
state_columns=["M_state"]
cov_diff_columns=[]
for i in range(len(path_suffix)):
    if i>0:
        suffix=path_suffix[i]
        column_names.append("SE_time")
        column_names.append("SE_state")
        column_names.append("SE_cov")
        cov_columns.append("SE_cov")
        time_columns.append("SE_time")
        state_columns.append("SE_state")            
        cov_diff_columns.append("cov_diff_Mythril_SE")
        
select_cols=[1,2,3,4,10,12]
select_column_names=["sol name",  "solc" , "contract","time","state","coverage"]
max_length=0
 
for vul in target_vul:
    df_combined_results=pd.DataFrame()
    
    for i in range(len(path_suffix)):
        if i==0:
            csv_file=_dir+results_mythril_prefix+vul+path_suffix[i]+"_csv.csv"
            data_array,max_len=wu.convert_csv_to_ndarray_0(csv_file)
            # extract the useful information
            df_combined_results= pd.DataFrame(data_array[:,select_cols], columns=select_column_names)
            
            df_combined_results.loc[(df_combined_results.time == '-'),'time']='0' 
            df_combined_results.loc[(df_combined_results.state == '-'),'state']='0' 
            df_combined_results["coverage"]=df_combined_results["coverage"].map(lambda x: x.rstrip('%'))            
            df_combined_results.loc[(df_combined_results.coverage== '-'),'coverage']='0'            
            df_combined_results["coverage"]=pd.to_numeric(df_combined_results["coverage"], downcast="float")
        else:            
            csv_file=_dir+results_smartExecutor_prefix+vul+path_suffix[i]+"_csv.csv" 
            data_array,max_len=wu.convert_csv_to_ndarray_0(csv_file)
             # extract the useful information
            df_temp= pd.DataFrame(data_array[:,select_cols], columns=select_column_names)
            df_temp.loc[(df_temp.time == '-'),'time']='0' 
            df_temp.loc[(df_temp.state == '-'),'state']='0' 
            df_temp["coverage"]=df_temp["coverage"].map(lambda x: x.rstrip('%'))            
            df_temp.loc[(df_temp.coverage== '-'),'coverage']='0'            
            df_temp["coverage"]=pd.to_numeric(df_temp["coverage"], downcast="float")
            df_combined_results=df_combined_results.merge(df_temp,on=["sol name",  "solc" , "contract"])
            
        if max_len>max_length:
            max_length=max_len
    df_combined_results.columns=column_names
    df_combined_results.to_csv(_dir+vul+"_time_states_coverage.csv", sep=',') 
            
    
    # do not filter any rows
    df_filtered=df_combined_results
    
    
    
    # get the average values for execution time, the number of states, and code coverage  
    statistics=[]
    statistics_columns=["ave time","ave #_of_states","ave cov",">10","(5,10]","(0,5]","=0","[-5,0)","[-10,5)","<-10"]
    indices=["Mythril(tx2)","SE"]
    
    for i in range(0,len(path_suffix)):
        re=[]       
                
        # get the coverage diff
        coverage_obj=df_filtered[cov_columns[i]].values
        time_obj=df_filtered[time_columns[i]].values
        state_obj=df_filtered[state_columns[i]].values
      
        re.append( np.average(time_obj.astype(np.int)))
        re.append(np.average(state_obj.astype(np.int)))
        re.append(np.average(coverage_obj))
                
        if i>0:  
            # get the coverage diff
            # cov_obj=df_filtered.apply(lambda x:f(x[cov_columns[0]],x[cov_columns[i]]),axis=1).values
            cov_obj=np.subtract(df_filtered[cov_columns[0]].values,coverage_obj)
            re.append(len(cov_obj[np.where(cov_obj>10)]))
            re.append(len(cov_obj[np.where((cov_obj>5) & (cov_obj<=10))]))
            re.append(len(cov_obj[np.where((cov_obj>0) & (cov_obj<=5))]))
            re.append(len(cov_obj[np.where(cov_obj==0)]))
            re.append(len(cov_obj[np.where((cov_obj>=-5) & (cov_obj<0))]))
            re.append(len(cov_obj[np.where((cov_obj>=-10) & (cov_obj<-5))]))
                       
            re.append(len(cov_obj[np.where(cov_obj<-10)]))        
        statistics.append(re)
    
       
    df_statistics=pd.DataFrame(statistics,columns=statistics_columns,index=indices)       
    df_statistics.to_csv(_dir+vul+"_statistics.csv", sep=',')        
 
    
 
    
 
    
 
    
 
    

            
# #====================================
# merge csv files to get the vulnerabilities
# #====================================    
    
select_columns_for_vul=[1,2,3,12] # initialize the columns that will be selected for vulnerability handle
                                # column with index 12 is used to filter data
                                # columns indexed by 1,2,3 are used to connect the dat


# get the indices of the columns that are to be selected

columns_names_vul=["sol name",  "solc" , "contract","coverage"] 
start_index=1+3+4+3+6
for i in range(start_index,max_length):
    select_columns_for_vul.append(i)
    columns_names_vul.append("vul_"+str(i-start_index))  
        
   
# merge results


for vul in target_vul:
    df_combined_results_vul=pd.DataFrame()
    for i in range(len(path_suffix)): 
        if i==0:
            path=_dir+results_mythril_prefix+vul+path_suffix[i]+"_csv.csv"
            data_mythril,_=wu.convert_csv_to_ndarray(path,max_length)            
            # extract the useful information
            df_combined_results_vul= pd.DataFrame(data_mythril[:,select_columns_for_vul], columns=columns_names_vul)
            df_combined_results_vul["coverage"]=df_combined_results_vul["coverage"].map(lambda x: x.rstrip('%'))            
            df_combined_results_vul.loc[(df_combined_results_vul.coverage == '-'),'coverage']='0'            
            df_combined_results_vul["coverage"]=pd.to_numeric(df_combined_results_vul["coverage"], downcast="float")
                       
        else:
            path=_dir+results_smartExecutor_prefix+vul+path_suffix[i]+"_csv.csv" 
            data_smartExecutor,_=wu.convert_csv_to_ndarray(path,max_length) 
            # extract the useful information 
            df_temp=pd.DataFrame(data_smartExecutor[:,select_columns_for_vul], columns=columns_names_vul)
            df_temp["coverage"]=df_temp["coverage"].map(lambda x: x.rstrip('%'))
            df_temp.loc[(df_temp.coverage == '-'),'coverage']='0'
            df_temp["coverage"]=pd.to_numeric(df_temp["coverage"], downcast="float")            
            df_combined_results_vul = df_combined_results_vul.merge(df_temp, on=["sol name",  "solc" , "contract"])
     

    # rename columns  
    rename_column_names=["sol name",  "solc" , "contract"]   
    for i in range(len(path_suffix)):
        if i>0:
            suffix=path_suffix[i]
            for item in columns_names_vul[3:]:
                rename_column_names.append("SE"+suffix+"_"+item)
        else:
            for item in columns_names_vul[3:]:
                rename_column_names.append('M_'+item)
    # output results to a csv file
    df_combined_results_vul.columns=rename_column_names
    df_combined_results_vul.to_csv(_dir+vul+"_vul.csv", sep=',')


      







        
   