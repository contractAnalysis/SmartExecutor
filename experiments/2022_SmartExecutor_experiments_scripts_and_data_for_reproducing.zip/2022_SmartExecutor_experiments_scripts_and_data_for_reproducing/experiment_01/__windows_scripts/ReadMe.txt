#================================================================
December 23th, 2021

experiment_01:

mythril_schedule_multiple_containers_windows.bat mythril_container 0 19 700 600 2

docker pull 23278942/contract_analysis:SmartExecutor-07   
smartExecutor_schedule_multiple_containers_windows_se07.bat smartExecutor_container 0 19 700 600 5 3 1 1


#================================================================
December 4th, 2021

folders: 
	python_code: contains python scripts that include one geting csv data files from given the give dataset of sGuard
	csv_data_files: contains the contract information for each Docker container(Solidity file, solc version, contract name)
	sGuard_contracts: the smart contracts from paper sGuard

Environment:
	Windows 10, with docker installed

download Mythril and SmartExecutor docker images
	docker pull 23278942/contract_analysis:mythril_Original_modified    # download Mythril image
	docker pull 23278942/contract_analysis:SmartExecutor-05             # download Mythril image

docker setting
	memory:16*20+16*2=352G
	cpu:2*20+2*2=44
	container: memory 16G, cpu 2

parameter setting:
	in mythril_docker_container_schedule.bat file and smartExecutor_docker_container_schedule.bat,
	parameters:
	 	workspace: set to the directory where these files locate
			e.g., set workspace=C:\Users\SERC\wei_experiments\_2021_fall_exp\exp_1	
		image: the docker image id of the tool that you want to run experiments
	
run Mythril
example command:

	mythril_docker_container_schedule.bat mythril_container 0 19 700 600

	mythril_docker_container_schedule.bat:==the batch file that starts the experiments for Mythril
 	mythril_container:==the prefix of the Docker container names
 	0:==the start index of the Docker container names
 	19:==the end index of the Docker container names
 	700:==the cli timeout, which force the termination in case Mythril fails to terminate after the given timeout reaches
 	600:==the execution timeout set for Mythril

run smartExecutor
example command:

	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 19 700 600 5 3 1 1
	
	the first 6 parameters are the same as Mythril
	5:== value of the control level, 5 means that parent subsets are randomly selected
	3:== 3 parent subsets are randomly selected. 
	1:== 1 sequence is generated for each parent seqeuence subset
	1:== index of times to run the expriments. 


other useful commands:	
	docker_container_delete.bat  mythril_container 0 19  # delete created containers



#================================================================
December 4th, 2021

run Mythril on sGuard dataset with timeout 900
	mythril_docker_container_schedule.bat mythril_container 0 19 700 600
 	docker_container_delete.bat  mythril_container_600 0 19  # delete created containers

	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 19 700 600 5 3 1 1


#================================================================
December 7th, 2021

Mythril add one more option: transaction count or depth: -depth
---------------------------------------------
mythril_docker_container_schedule.bat mythril_container 0 0 700 600 2
mythril_docker_container_schedule.bat mythril_container 1 1 700 600 3
smartExecutor_docker_container_schedule.bat smartExecutor_container 2 2 700 600 5 3 1 1
smartExecutor_docker_container_schedule.bat smartExecutor_container 3 3 700 600 5 3 1 2
smartExecutor_docker_container_schedule.bat smartExecutor_container 4 4 700 600 5 3 1 3

mythril_docker_container_schedule.bat mythril_container 5 5 1000 900 2
mythril_docker_container_schedule.bat mythril_container 6 6 1000 900 3
smartExecutor_docker_container_schedule.bat smartExecutor_container 7 7 1000 900 5 3 1 1
smartExecutor_docker_container_schedule.bat smartExecutor_container 8 8 1000 900 5 3 1 2
smartExecutor_docker_container_schedule.bat smartExecutor_container 9 9 1000 900 5 3 1 3

mythril_docker_container_schedule.bat mythril_container 10 10 1300 1200 2
mythril_docker_container_schedule.bat mythril_container 11 11 1300 1200 3
smartExecutor_docker_container_schedule.bat smartExecutor_container 12 12 1300 1200 5 3 1 1
smartExecutor_docker_container_schedule.bat smartExecutor_container 13 13 1300 1200 5 3 1 2
smartExecutor_docker_container_schedule.bat smartExecutor_container 14 14 1300 1200 5 3 1 3

mythril_docker_container_schedule.bat mythril_container 15 15 400 300 2
mythril_docker_container_schedule.bat mythril_container 16 16 400 300 3
smartExecutor_docker_container_schedule.bat smartExecutor_container 17 17 400 300  5 3 1 1
smartExecutor_docker_container_schedule.bat smartExecutor_container 18 18 400 300  5 3 1 2
smartExecutor_docker_container_schedule.bat smartExecutor_container 19 19 400 300  5 3 1 3
---------------------------------------------

mythril_docker_container_schedule.bat mythril_container 15 15 1600 1500 2
mythril_docker_container_schedule.bat mythril_container 16 16 1600 1500 3
smartExecutor_docker_container_schedule.bat smartExecutor_container 17 17 1600 1500  5 3 1 1
smartExecutor_docker_container_schedule.bat smartExecutor_container 18 18 1600 1500  5 3 1 2
smartExecutor_docker_container_schedule.bat smartExecutor_container 19 19 1600 1500  5 3 1 3





#================================================================
December 9th, 2021
	
	docker pull 23278942/contract_analysis:SmartExecutor-06      
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 19 700 600 5 3 2 1
	





#================================================================
December 11th, 2021

	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 19 700 600 5 6 1 1


docker_container_delete.bat  mythril_container__1500_tx3 16 16
docker_container_delete.bat smartExecutor_container_5_6_1_1_600 0 19


#================================================================
here the history

docker pull 23278942/contract_analysis:mythril_Original_modified
mythril_docker_container_schedule.bat mythril_container 0 19



docker pull 23278942/contract_analysis:SE_Guider
se_guider_docker_container_schedule.bat se_guider_container 0 19



docker pull 23278942/contract_analysis:SE_Guider_3
docker_container_delete.bat se_guider_container 0 19

#================================
docker setting
memory:16*20+16*2=352G
cpu:2*20+2*2=44
container: memory 16G, cpu 2

#=================================
August 20,2021

docker pull 23278942/contract_analysis:SE_Guider_paper_1
se_guider_docker_container_schedule.bat se_guider_container 0 19



#=================================
August 25,2021
use the version of adding level control

1 container_name_prefix=%1
2 con_start_index=%2
3 con_end_index=%3

4 cli_timeout=%4
5 create_timeout=%5
6 execution_timeout=%6

7 control_level=%7

docker pull 23278942/contract_analysis:SE_Guider_paper

se_guider_docker_container_schedule.bat se_guider_container_paper_3 0 19 960 10 900 3
se_guider_docker_container_schedule.bat se_guider_container_paper_2 0 19 960 10 900 2
se_guider_docker_container_schedule.bat se_guider_container_paper_4 0 19 960 10 900 4
se_guider_docker_container_schedule.bat se_guider_container_paper_1 0 19 960 10 900 1

docker_container_delete.bat se_guider_container_paper_3 0 19


docker_container_delete.bat se_guider_container_paper_3 0 19
#===============================================
September 8,2021 (directly use valid sequences from FDG-guided execution phase in sequence execuction)
(data dependency in FDG)
docker pull 23278942/contract_analysis:SE-Guider-2

se_guider_docker_container_schedule.bat se_guider_container 0 19 960 10 900 2
docker_container_delete.bat se_guider_container 0 19
#===============================================
September 13,2021 (data dependency in FDG, use valid sequences from FDG-guided execution phase)
docker pull 23278942/contract_analysis:SE-Guider
se_guider_docker_container_schedule.bat se_guider_container 0 19 960 10 900 2
#===============================================
September 16,2021 (data and control dependency in FDG, use valid sequences from FDG-guided execution phase, sequences do not have repeated elements)
docker pull 23278942/contract_analysis:SE-Guider-1
se_guider_docker_container_schedule.bat se_guider_container 0 19 960 10 900 2
docker_container_delete.bat se_guider_container 0 19

#===============================================
September 20,2021 (data and control dependency in FDG, use valid sequences from FDG-guided execution phase, sequences do not have repeated elements)
fix a bug related to keyerror in sequence packing

docker pull 23278942/contract_analysis:SE-Guider-1
se_guider_docker_container_schedule.bat se_guider_container 0 19 960 10 900 2
docker_container_delete.bat se_guider_container 0 19

#===============================================
September 24,2021 (data and control dependency in FDG, use valid sequences from FDG-guided execution phase, sequences do not have repeated elements)
fix a bug occuring when self._iteration_==0


docker pull 23278942/contract_analysis:SE-Guider-1
se_guider_docker_container_schedule.bat se_guider_container 0 19 960 10 900 2
docker_container_delete.bat se_guider_container 0 19



#===============================================
September 29,2021 sequence execution: execute sequence one by one(on one state at a time)

docker pull 23278942/contract_analysis:SE-Guider-3
se_guider_docker_container_schedule.bat se_guider_container 0 19 960 10 900 2
docker_container_delete.bat se_guider_container 0 19


#===============================================
October 1, 2021 change name

increase 1 parameter:
set print_ftn_cov=%8: 1, print; 0, do not print

docker pull 23278942/contract_analysis:SmartExecutor-01

# test before run experiments
smartExecutor_docker_container_schedule__.bat smartExecutor_container 13 15 960 10 900 2 1

# run experiments
smartExecutor_docker_container_schedule.bat smartExecutor_container 0 19 960 10 900 2 0
docker_container_delete.bat smartExecutor_container 0 0


#===============================================
October 24, 2021 
SmartExecutor-02:
consider self-dependency, and remove redundant state feasibility checking

docker pull 23278942/contract_analysis:SmartExecutor-02

# run experiments
smartExecutor_docker_container_schedule.bat smartExecutor_container 0 19 960 10 900 2 0



#===============================================
October 27, 2021 
SmartExecutor-03:

topological sorting is applied in sequence generation
add control level: 6,7,8
add option flag: --sequence-number-limit

docker pull 23278942/contract_analysis:SmartExecutor-03
# run experiments
smartExecutor_docker_container_schedule.bat smartExecutor_container 0 19 960 10 900 6 0 5
docker_container_delete.bat smartExecutor_container 0 19



#===============================================
November 5, 2021 
SmartExecutor-04:

topological sorting is applied in sequence generation
add control level: 6,7,8
add option flag: --sequence-number-limit
self-dependency is removed

docker pull 23278942/contract_analysis:SmartExecutor-04
# run experiments
smartExecutor_docker_container_schedule.bat smartExecutor_container 0 19 960 10 900 6 0 5

docker_container_delete.bat smartExecutor_container 0 19

#===============================================
November 8, 2021
SmartExecutor-04: revised to output information that indicate if sequence execution is involved.
docker pull 23278942/contract_analysis:SmartExecutor-04
# run experiments to identify contracts that will go through the sequence execution phase.
smartExecutor_docker_container_schedule.bat smartExecutor_container 0 19 960 10 900 2 0 5

#===============================================
November 9, 2021
SmartExecutor-05: 
add control level 9: randomly select parents in sequence generation
revised to output information that indicate if sequence execution is involved.

notes: 
	--sequence-number-limit only affect when random selection is used in sequence generation (i.e., when control level equals 8 and 9

docker pull 23278942/contract_analysis:SmartExecutor-05
docker pull 23278942/contract_analysis:mythril_Original_modified

mythril_docker_container_schedule.bat mythril_container 0 1

smartExecutor_docker_container_schedule.bat smartExecutor_container_cl2 0 1 1900 10 1800 2 0 5

smartExecutor_docker_container_schedule.bat smartExecutor_container_cl6 0 1 1900 10 1800 6 0 5
docker_container_delete.bat smartExecutor_container_cl2 0 19

smartExecutor_docker_container_schedule.bat smartExecutor_container_cl7 0 1 1900 10 1800 7 0 5

smartExecutor_docker_container_schedule.bat smartExecutor_container_cl8_2 0 1 1900 10 1800 8 0 2
smartExecutor_docker_container_schedule.bat smartExecutor_container_cl8_5 0 1 1900 10 1800 8 0 5
smartExecutor_docker_container_schedule.bat smartExecutor_container_cl8_10 0 1 1900 10 1800 8 0 10

smartExecutor_docker_container_schedule.bat smartExecutor_container_cl9_2 0 1 1900 10 1800 9 0 2
smartExecutor_docker_container_schedule.bat smartExecutor_container_cl9_5 0 1 1900 10 1800 9 0 5
smartExecutor_docker_container_schedule.bat smartExecutor_container_cl9_10 0 1 1900 10 1800 9 0 10






#===============================================
November 16, 2021
SmartExecutor-05:  recode sequence generation. there are total 6 control levels:
1: all parents, merge sequences
2: all parents, topological sorting
3: parent subsets, merge sequences
4: parent subsets, topological sorting
5: randomly select parents, topological sorting
6: randomly select parents + a subset that includes all parents, topological sorting

seq_num_limit: -snl  the number of sequences generated for each parent sequence list
prt_subset_num_limit: -pnl  the number of parent subsets considered

docker pull 23278942/contract_analysis:SmartExecutor-05




# parameters: container prefix, container start index, container end index, command line timeout, create timeout, execution timeout, control level, print coverage, parent_subset_num_limit, seq_num_limit

smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1900 10 1800 2 0 5

# in each batch, start 20 containers
docker_container_delete.bat smartExecutor_container_3_0_1 0 1

# first batch:
	mythril_docker_container_schedule.bat mythril_container 0 1
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1900 10 1800 3 0 10
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1900 10 1800 3 0 1
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1900 10 1800 3 0 2
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1900 10 1800 3 0 3
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1900 10 1800 3 0 4
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1900 10 1800 4 0 1
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1900 10 1800 4 0 2
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1900 10 1800 4 0 3
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1900 10 1800 4 0 4


# second batch:
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1900 10 1800 5 3 1
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1900 10 1800 6 3 1
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1900 10 1800 5 5 1
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1900 10 1800 6 5 1
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1900 10 1800 5 7 1
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1900 10 1800 6 7 1
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1900 10 1800 5 9 1
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1900 10 1800 6 9 1
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1900 10 1800 5 3 2
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1900 10 1800 6 3 2


# third batch:	
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1900 10 1800 5 5 2
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1900 10 1800 6 5 2
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1900 10 1800 5 7 2
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1900 10 1800 6 7 2
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1900 10 1800 5 9 2
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1900 10 1800 6 9 2
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1900 10 1800 5 3 3
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1900 10 1800 6 3 3
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1900 10 1800 5 5 3
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1900 10 1800 6 5 3

#===============================================
November 20, 2021
fix the bugs related to numpy random choice: ValueError: 'a' cannot be empty unless no samples are taken,    ValueError: Negative dimensions are not allowed

It means: the results of conetrol level 5 and 6 contain wrong data. they need to be re-run.
due to time limit before the next meeting: re-run the basic cases and the timeout is 900 (save time)

docker_container_delete.bat smartExecutor_container_6_5_3 1 1

docker pull 23278942/contract_analysis:SmartExecutor-05

	mythril_docker_container_schedule.bat mythril_container 0 1
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1000 10 900 3 0 10
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1000 10 900 5 3 1
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1000 10 900 6 3 1
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1000 10 900 5 6 1
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1000 10 900 6 6 1
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1000 10 900 5 3 2
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1000 10 900 6 3 2
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1000 10 900 5 6 2
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1000 10 900 6 6 2


#===============================================
November 22, 2021
docker pull 23278942/contract_analysis:SmartExecutor-05

docker_container_delete.bat  smartExecutor_container_3_0_10_1 0 1
docker_container_delete.bat  mythril_container_1200 0 1


mythril, case 1: my approach, case: randomly select 3 parent subsets and each parent sequence list only allows one sequence generated
	
	mythril_docker_container_schedule.bat mythril_container 0 1 1000 900
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1000 900 3 0 10 1 # run one time for case 1 as there is no randomness 	
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1000 900 5 3 1 1  # the 1st run for case 3
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1000 900 5 3 1 2  # the 2nd run for case 3
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1000 900 5 3 1 3  # the 3rd run for case 3

	mythril_docker_container_schedule.bat mythril_container 0 1 700 600
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 700 600 3 0 10 1 # run one time for case 1 as there is no randomness 	
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 700 600 5 3 1 1  # the 1st run for case 3
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 700 600 5 3 1 2  # the 2nd run for case 3
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 700 600 5 3 1 3  # the 3rd run for case 3

	mythril_docker_container_schedule.bat mythril_container 0 1 1300 1200
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1300 1200 3 0 10 1 # run one time for case 1 as there is no randomness 	
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1300 1200 5 3 1 1  # the 1st run for case 3
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1300 1200 5 3 1 2  # the 2nd run for case 3
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 1300 1200 5 3 1 3  # the 3rd run for case 3


#===============================================
November 26, 2021
at  Directory of C:\Users\SERC\wei_experiments\_2021_fall_exp\exp_1
smartExecutor_docker_container_schedule.bat smartExecutor_container 0 19 1000 900 5 3 1 1
smartExecutor_docker_container_schedule.bat smartExecutor_container 0 19 1000 900 5 3 1 2
smartExecutor_docker_container_schedule.bat smartExecutor_container 0 19 1000 900 5 3 1 3
docker_container_delete.bat  smartExecutor_container_5_3_1_1_900 0 19


#===============================================
November 29, 2021
at  Directory of C:\Users\SERC\wei_experiments\_2021_fall_exp\exp_2
	mythril_docker_container_schedule.bat mythril_container 0 1 400 300
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 400 300 3 0 10 1 # run one time for case 1 as there is no randomness 	
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 400 300 5 3 1 1  # the 1st run for case 3
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 400 300 5 3 1 2  # the 2nd run for case 3
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 1 400 300 5 3 1 3  # the 3rd run for case 3

to do:


#===============================================
November 30, 2021
at  Directory of C:\Users\SERC\wei_experiments\_2021_fall_exp\exp_1
	mythril_docker_container_schedule.bat mythril_container 0 19 700 600
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 19 700 600 5 3 1 1
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 19 700 600 5 3 1 2
	smartExecutor_docker_container_schedule.bat smartExecutor_container 0 19 700 600 5 3 1 3

docker_container_delete.bat  mythril_container 0 19