#============================================================================================================
# find contracts that go through seqeuence generation phase
#============================================================================================================

import sys
import os
import csv
import pandas as pd
sys.path.append('C:\\Users\\18178\\_2022_exp\\python_code\\') # where the wei_utils.py resides
import wei_utils as wu
import numpy as np     
import shutil
import math

_dir_base='C:\\Users\\18178\\_2022_exp\\experiment_01\\'

target='windows'
_dir=_dir_base+'__'+target+'_results\\'
num_group=10



results_smartExecutor_prefix="results_smartExecutor_" 
 
path_suffix=['5_3_1_1_600_']     
   
files=['5_3_1_1_600_*.csv']
  
merged_files=["cl5_3_1_1_600.csv"]
 
merged_smartExecutor_prefix='merged_smartExecutor_'
 
csv_prefix='sGuard_contracts_info_seq_'+target+"_"
csv_folder="csv_metadata_files_"+target+"_seq"


 
# #====================================
# extract results into csv files
# #====================================    
all_contracts_data_cut_down={}    
   
for i in range(len(path_suffix)):
    for index in range(0,20,1):

        dir = _dir+ results_smartExecutor_prefix +  path_suffix[i] + str(index)+'/'
        csv_file_name = _dir + results_smartExecutor_prefix +  path_suffix[i] +str(index)+"__csv.csv"
            
        all_files = wu.find_all_file(dir,'txt')
        re = wu.iterate_files(all_files)
        
        contracts_data_cut_down=wu.output_csv(re, csv_file_name)
        if contracts_data_cut_down:
            all_contracts_data_cut_down['part'+str(index)]=contracts_data_cut_down
print(all_contracts_data_cut_down)

 
    
        
    
# #====================================
# combine all csv files of the same type into one csv files by executing windows commands
# #====================================

# #====================================
# # windows command to merge multiple csv files
# example: copy results_mythril_*.csv merged_mythril.csv  
        
for i in range(len(path_suffix)): 
    target_files=_dir+results_smartExecutor_prefix+files[i]
    target_merged_file=_dir+merged_smartExecutor_prefix+merged_files[i]
        
    os.system("copy {} {}".format(target_files,target_merged_file))
    

# #====================================
# get the contracts that go through sequence generation
# #====================================
df_contracts_seq=pd.DataFrame()
for index in range(len(merged_files)):     
    # convert csv data into an array
    path=_dir+merged_smartExecutor_prefix+merged_files[index] 
    data_selected,max_len_smartExecutor=wu.convert_csv_to_ndarray_0(path) 
    # extract the useful information 
    df_temp=pd.DataFrame(data_selected[:,[0,1,2,3]], columns=["seq","sol name", "solc" , "contract"])
    
    df_contracts_seq =  df_temp[df_temp["seq"]=="True"]
    df_contracts_info=df_contracts_seq.iloc[:,[1,2,3]]

# check if a directory exists or not
csv_folder_dir=_dir_base+csv_folder  
if os.path.isdir(csv_folder_dir):
     shutil.rmtree(csv_folder_dir)
os.mkdir(csv_folder_dir)
    

#=================================
# 4, divide evenly contract info into 20 csv files
# 5, make each line end with \n insteand of \r\n
# divided into 20 groups and get the size for each group
group_size=math.floor((df_contracts_info.shape[0]/num_group))
left=df_contracts_info.shape[0]-num_group*group_size
group_size_list=num_group*[group_size]
for i in range(left):
    group_size_list[i]+=1
index=0
index_start=0
for group_size in group_size_list:
    group=df_contracts_info.iloc[index_start:index_start+group_size]
    # get two copies for each csv file
    group.to_csv(csv_folder_dir+"\\"+csv_prefix+"part_"+str(index)+".csv",index=False, header=False,sep=',', line_terminator='\n')
    group.to_csv(csv_folder_dir+"\\"+csv_prefix+"part_"+str(index+10)+".csv",index=False, header=False,sep=',', line_terminator='\n')
    
    index+=1
    index_start+=group_size
    
    
    
# randomly select 100 contracts
indices=list(range(df_contracts_info.shape[0]))
np.random.seed(100)
selected_indices=np.random.choice(indices, size=100, replace=False)
print(selected_indices)
df_contracts_info_100=df_contracts_info.iloc[selected_indices,:]
# save 7 copies
for i in range(7):
    df_contracts_info_100.to_csv(csv_folder_dir+"\\"+csv_prefix+"part_"+str(i)+".csv",index=False, header=False,sep=',', line_terminator='\n')
    












#============================================================================================================
# Result collection
# 
# plot data
#============================================================================================================

import sys
import os
import csv
import pandas as pd
sys.path.append('C:\\Users\\18178\\_2022_exp\\python_code\\') # where the wei_utils.py resides
import wei_utils as wu
import numpy as np     
import shutil
import math
import statistics
_dir_base='C:\\Users\\18178\\_2022_exp\\experiment_04\\'

target='windows'
_dir=_dir_base+'__'+target+'_results\\'


#============================================================================================================
# get statistics from results
#============================================================================================================


results_smartExecutor_prefix="results_smartExecutor_"
results_mythril_prefix="results_mythril_" 
 
path_suffix=['600_tx2_','5_3_1_1_600_']     
   
files=['600_tx2_*.csv','5_3_1_1_600_*.csv']
  
merged_files=['_600_tx2.csv','_5_3_1_1_600.csv']
 
merged_smartExecutor_prefix='merged_smartExecutor_'
merged_mythril_prefix='merged_mythril_'

csv_prefix="final_results_"


results_SE_prefix='results_smartExecutor_seq_5_3_1_'
mid_indices=list(range(4,15,1))



 
# #====================================
# extract results into csv files
# #====================================    
all_contracts_data_cut_down={}    
   

for index in range(0,10,1):
    dir = _dir+ results_SE_prefix + str(mid_indices[index])+"_600_"+ str(index)+'/'
    csv_file_name = _dir + results_SE_prefix + str(mid_indices[index])+"_600_"+ str(index)+"__csv.csv"
    all_files = wu.find_all_file(dir,'txt')
    re = wu.iterate_files(all_files)
 
    contracts_data_cut_down=wu.output_csv(re, csv_file_name)
    if contracts_data_cut_down:
        all_contracts_data_cut_down[f'part_tool_{mid_indices[index]}_{index}']=contracts_data_cut_down      
            
print(all_contracts_data_cut_down)

 
    

# #====================================
# get the data from merged files
# #====================================
max_vul_len=0
df_SE=pd.DataFrame()
for index in range(10):
    path= _dir + results_SE_prefix + str(mid_indices[index])+"_600_"+ str(index)+"__csv.csv"
    data_array,max_len=wu.convert_csv_to_ndarray_0(path)
    if max_len>max_vul_len:
        max_vul_len=max_len
    df_SE_temp=pd.DataFrame(data_array)
    df_SE_temp=df_SE_temp[[1,2,3,4,10,12]]
    if index==0:
        df_SE=df_SE_temp
    else:
        df_SE=df_SE.merge(df_SE_temp,on=[1,2,3])
df_SE.columns=list(range(df_SE.shape[1]))
df_SE.to_csv(_dir_base+"combined_data.csv")


# # get column indices for execution time
# time_col_indices=[]
# states_col_indices=[]
# coverage_col_indices=[]
# for i in range(10):
#     time_col_indices.append(3+i*3)
#     states_col_indices.append(4+i*3)
#     coverage_col_indices.append(5+i*3)   
    
# df_time=df_SE[time_col_indices] 
# df_states=df_SE[states_col_indices]  
# df_coverage=df_SE[coverage_col_indices]
# df_coverage=df_coverage.apply(lambda x: float(str(x).strip('%')))


# std_time=[]
# for index, row in df_time.iterrows(): 
#     data_row=list(map(int,row))
#     print(data_row)
#     std_time.append(statistics.stdev(data_row))

# std_states=[]
# for index, row in df_states.iterrows():  
#     data_row=[int(item) for item in list(row) if '-' not in item] 
#     print(data_row)
#     std_states.append(statistics.stdev(data_row))  
    
# std_coverage=[]
# for index, row in df_coverage.iterrows():  
#     data_row=[float(str(item).strip("%")) for item in list(row) if '-' not in item] 
#     print(data_row)
#     std_coverage.append(statistics.stdev(data_row))  


df_vul_se=pd.DataFrame()
columns_names_vul=["sol name",  "solc" , "contract","time","num_states","coverage"] 
select_columns_for_vul=[1,2,3,4,10,12]

start_index=1+3+4+3+6
for i in range(start_index,max_vul_len):
    select_columns_for_vul.append(i)
    columns_names_vul.append("vul_"+str(i-start_index))  

for i in range(10):    
    path= _dir + results_SE_prefix + str(mid_indices[i])+"_600_"+ str(i)+"__csv.csv"
    data_array,_=wu.convert_csv_to_ndarray(path,max_vul_len)
    
    df_vul_se_temp=pd.DataFrame(data_array)
    df_vul_se_temp=df_vul_se_temp[select_columns_for_vul]
    if i==0:
        df_vul_se=df_vul_se_temp
    else:
        df_vul_se=df_vul_se.merge(df_vul_se_temp,on=[1,2,3])
        
df_vul_se.columns=list(range(df_vul_se.shape[1]))
df_vul_se.to_csv(_dir_base+"combined_data_vul.csv") 


interval=max_vul_len-start_index+3
# get column indices for execution time
time_col_indices=[]
states_col_indices=[]
coverage_col_indices=[]
vul_col_indices=[]

for i in range(10):
    time_col_indices.append(3+i*interval)
    states_col_indices.append(4+i*interval)
    coverage_col_indices.append(5+i*interval) 
    vul_col_indices+=list(np.add(list(range(6,13,1)),i*interval))
    
df_time=df_vul_se[time_col_indices] 
df_states=df_vul_se[states_col_indices]  
df_coverage=df_vul_se[coverage_col_indices]
df_vul=df_vul_se[vul_col_indices]


   
std_time=[]
cv_time=[]
for index, row in df_time.iterrows(): 
    data_row=list(map(int,row))
    # print(data_row)
    std_time.append(statistics.stdev(data_row))
    if statistics.mean(data_row)!=0:
        cv_time.append(statistics.stdev(data_row)/statistics.mean(data_row))
    else:
        print(data_row)
        cv_time.append(0)
        
std_states=[]
cv_states=[]
for index, row in df_states.iterrows():  
    data_row=[int(item) for item in list(row) if '-' not in item] 
    # print(data_row)
    std_states.append(statistics.stdev(data_row)) 
    if statistics.mean(data_row)!=0:
        cv_states.append(statistics.stdev(data_row)/statistics.mean(data_row)) 
    else:
        print(data_row)
        cv_states.append(0)
        
std_coverage=[]
cv_coverage=[]
for index, row in df_coverage.iterrows():  
    data_row=[float(str(item).strip("%")) for item in list(row) if '-' not in item] 
    # print(data_row)
    std_coverage.append(statistics.stdev(data_row)) 
    if statistics.mean(data_row)!=0:
        cv_coverage.append(statistics.stdev(data_row)/statistics.mean(data_row)) 
    else:
        print(data_row)
        cv_coverage.append(0)
        

count_num=[]
count_type=[]

for index,row in df_vul.iterrows():
    cnt_num=[]
    cnt_type=[]
    for i in range(10):
        vul_data=row[list(np.add(list(range(6,13,1)),i*interval))]
        vul_dict={}       
        for item in  vul_data:
            if str(item).__contains__(':'):
                vul_dict[str(item).split(':')[0]]=int(str(item).split(':')[1])
        cnt_type.append(len(vul_dict.keys()))
        num=0
        for value in vul_dict.values():
            num+=value
        cnt_num.append(num)
    count_num.append(cnt_num)
    count_type.append(cnt_type)
    
std_num_vul=[]
std_type_vul=[]
cv_num_vul=[]
cv_type_vul=[]
num_vul_0=0
type_vul_0=0
for item in count_num:
    std_num_vul.append(statistics.stdev(item)) 
    if statistics.mean(item)!=0:
        cv_num_vul.append(statistics.stdev(item)/statistics.mean(item))
    else:
        print(item )
        cv_num_vul.append(0)
        num_vul_0+=1
        
for item in count_type:
    std_type_vul.append(statistics.stdev(item))   
    if statistics.mean(item)!=0:
        cv_type_vul.append(statistics.stdev(item)/statistics.mean(item))  
    else:
        print(item )
        type_vul_0+=1
        cv_type_vul.append(0)
      
 # count the number of contracts, the standard deviations of which fall in three interval   
std_time_count=[]
std_time_count.append(len(list(x for x in std_time if x==0)))
std_time_count.append(len(list(x for x in std_time if 0<x<=1)))
std_time_count.append(len(list(x for x in std_time if 1< x)))


std_states_count=[]
std_states_count.append(len(list(x for x in std_states if x==0)))
std_states_count.append(len(list(x for x in std_states if 0<x<=1)))
std_states_count.append(len(list(x for x in std_states if 1< x)))


std_coverage_count=[]
std_coverage_count.append(len(list(x for x in std_coverage if x==0)))
std_coverage_count.append(len(list(x for x in std_coverage if 0<x<=1)))
std_coverage_count.append(len(list(x for x in std_coverage if 1< x)))

std_num_vul_count=[]
std_num_vul_count.append(len(list(x for x in std_num_vul if x==0)))
std_num_vul_count.append(len(list(x for x in std_num_vul if 0<x<=1)))
std_num_vul_count.append(len(list(x for x in std_num_vul if 1< x)))


std_type_vul_count=[]
std_type_vul_count.append(len(list(x for x in std_type_vul if x==0)))
std_type_vul_count.append(len(list(x for x in std_type_vul if 0<x<=1)))
std_type_vul_count.append(len(list(x for x in std_type_vul if 1< x)))


      







#=====================================
# boxplots for coverage, types of vul and num of vul
#------------------------------------

import matplotlib.pyplot as plt
import pandas as pd

data=pd.DataFrame([cv_type_vul,cv_num_vul,cv_coverage]).transpose()

labels = ['Types of Vul','Numbers of Vul','Contract Coverage']
#------------------------------------
fig, axes = plt.subplots(1,1,figsize=(6,4)) # create figure and axes

b1=axes.boxplot(data, patch_artist=True, labels=labels)
axes.set_ylabel("Coefficient of Variation") 
# axes.legend((b1['boxes'][0],b1['boxes'][1],b1['boxes'][2]), ("M2: Mythril (depth limit = 2)","SE: SmartExecutor","M3: Mythril (depth limit = 3)"),\
# loc="lower left", bbox_to_anchor=(0,0.8))


# fill with colors
colors = ['pink', '#038FC8', 'lightgreen']
for bplot in [b1]:
    for patch, color in zip(bplot['boxes'], colors):
        patch.set_facecolor(color)
        
# # adding horizontal grid lines
# for ax in axes:
#     ax.yaxis.grid(True)
#     # ax.set_xlabel('Execution Time')
#     # ax.set_ylabel('Observed values') 

# fig.legend((b1['boxes'][0],b1['boxes'][1],b1['boxes'][2]), ("M2: Mythril (depth limit = 2)","SE: SmartExecutor","M3: Mythril (depth limit = 3)"),\
#             loc="lower left", bbox_to_anchor=(0.2,0.7))
    
fig.tight_layout()

plt.savefig(_dir_base+"stablility_boxplots_RQ3.pdf")
plt.show()



#=========================================================
# plot in bar chart

std_categories=['std = 0','0 < std <= 1','1 < std']
my_data_other=[std_num_vul_count,std_type_vul_count,std_coverage_count]

"""
========
Barchart
========

A bar plot with errorbars and height labels on individual bars
"""
import numpy as np
import matplotlib.pyplot as plt


std_0=[std_type_vul_count[0],std_num_vul_count[0],std_coverage_count[0]]
std_1=[std_type_vul_count[1],std_num_vul_count[1],std_coverage_count[1]]
std_m=[std_type_vul_count[2],std_num_vul_count[2],std_coverage_count[2]]

std_categories=['std = 0','0 < std <= 1','1 < std']
x_label=['Number of Vul','Types of Vul','Code Coverage']



N = 3
ind = np.arange(N)  # the x locations for the groups

# ind=[0,2,4]
width = 0.25       # the width of the bars

fig, ax = plt.subplots()

rects5 = ax.bar(ind, std_1, width, color='w')  # color white. only for seperation purpose
rects1 = ax.bar(ind + width, std_0, width, color='#1486B5')
rects2 = ax.bar(ind + 2*width, std_1, width, color='y')
rects3 = ax.bar(ind + 3*width, std_m, width, color='g')
rects4 = ax.bar(ind + 4*width, std_1, width, color='w')   # color white, only for seperation purpose


# add some text for labels, title and axes ticks
ax.set_ylabel('Number of Contracts')
# ax.set_title('Scores by group and gender')
ax.set_xticks(ind + 2*width ) # set the tick positions
ax.set_xticklabels(x_label)

ax.legend((rects1[0], rects2[0],rects3[0],rects4[0],rects5[0]), std_categories+['std: standard deviation','vul: vulnerabilities'])


def autolabel(rects):
    """
    Attach a text label above each bar displaying its height
    """
    for rect in rects:
        height = rect.get_height()
        ax.text(rect.get_x() + rect.get_width()/2., height,
                '%d' % int(height),
                ha='center', va='bottom')

autolabel(rects1)  # plot the values on top of bars
autolabel(rects2)
autolabel(rects3)

plt.savefig(_dir_base+'bar_chart_stableness_data.pdf')
plt.show()
